package org.designstudy.violeta

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
