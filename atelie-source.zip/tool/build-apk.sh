#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v flutter >/dev/null 2>&1; then
  echo 'Instale Flutter 3.29.3 e adicione flutter/bin ao PATH.' >&2
  exit 1
fi
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build apk --release
printf '\nAPK: %s/build/app/outputs/flutter-apk/app-release.apk\n' "$PWD"
