"""Select a standalone study without including other institutions' image assets."""
import os
from pathlib import Path
family=os.environ.get('STUDY_FAMILY','all')
assets={
 'all':None,
 'nubank':{'reference.jpg','nu-claro.jpg','nu-promos.jpg','nubank.svg'},
 'bb':{'bb-reference.jpg'},
 'next':{'next-iniciais.jpg','next-foto.jpg','next-transferencia.jpg'},
 'bradesco':{'bradesco.jpg'},
 'pagbank':{'pagbank.jpg'},
 'binance':{'binance.jpg'},
 'cooperativa':{'cooperativa.jpg'},
}
assert family in assets, 'Unknown study family'
if family!='all':
 for asset in Path('assets').iterdir():
  if asset.is_file() and asset.name not in assets[family]: asset.unlink()
 gradle=Path('android/app/build.gradle.kts')
 source=gradle.read_text().replace('applicationId = "org.designstudy.violeta"',f'applicationId = "org.designstudy.atelie.{family}"')
 gradle.write_text(source)
 manifest=Path('android/app/src/main/AndroidManifest.xml')
 manifest.write_text(manifest.read_text().replace('Ateliê — Estudos',f'Ateliê · {family}'))
print('Edition:',family)
