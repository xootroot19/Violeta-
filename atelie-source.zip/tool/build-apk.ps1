$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
foreach ($arguments in @(@('pub','get'), @('analyze','--no-fatal-infos'), @('test'), @('build','apk','--release'))) {
  & flutter @arguments
  if ($LASTEXITCODE -ne 0) { throw "Flutter falhou: $arguments" }
}
Write-Host "APK: $PWD/build/app/outputs/flutter-apk/app-release.apk"
