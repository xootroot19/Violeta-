import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'model.dart';

class SceneSpec {
  final String id, family, title, variant, asset;
  final Color accent, background;
  final Map<String, Object> defaults;
  final Rect? avatar;
  const SceneSpec(this.id, this.family, this.title, this.variant, this.asset,
    this.accent, this.background, this.defaults, {this.avatar});
  bool get light => background.computeLuminance() > .5;
}
const sceneSpecs = <SceneSpec>[
  SceneSpec('nu-classico','nubank','Nubank','Clássico escuro','reference.jpg',Color(0xff69238f),Colors.black,{}),
  SceneSpec('nu-promos','nubank','Nubank','Destaques e missões','nu-promos.jpg',Color(0xff602087),Colors.black,{'balance':235588,'loan':1250000,'invoice':30487},avatar:Rect.fromLTWH(32,17,100,100)),
  SceneSpec('nu-claro','nubank','Nubank','Conta clara','nu-claro.jpg',Color(0xff8505cf),Colors.white,{'name':'Kayane','balance':20011756,'loan':1250000,'invoice':24813},avatar:Rect.fromLTWH(32,0,104,54)),
  SceneSpec('bb','bb','Banco do Brasil','Conta e Loja BB','bb-reference.jpg',Color(0xff2057f7),Color(0xfffcfefe),{}),
  SceneSpec('next-iniciais','next','next','Conta · iniciais','next-iniciais.jpg',Color(0xff00ef57),Colors.black,{'name':'RAFAELA R SOUZA','balance':2425000}),
  SceneSpec('next-foto','next','next','Conta · foto','next-foto.jpg',Color(0xff00ef57),Colors.black,{'name':'Cleber carvalho','balance':659697},avatar:Rect.fromLTWH(53,169,118,120)),
  SceneSpec('next-transferencia','next','next','Inserir valor','next-transferencia.jpg',Color(0xff00ef57),Colors.black,{'recipient':'CLAUDIA MARIA DE OLIVEIRA DA FONSECA','amount':80000,'balance':4397718}),
  SceneSpec('bradesco','bradesco','bradesco','Conta e serviços','bradesco.jpg',Color(0xffee0c50),Color(0xfff0f1f5),{'name':'Pedro','balance':52994}),
  SceneSpec('pagbank','pagbank','PagBank','Saldo e produtos','pagbank.jpg',Color(0xff51a934),Color(0xff51a934),{'balance':319779,'receivable':0}),
  SceneSpec('binance','binance','BINANCE','Portfólio','binance.jpg',Color(0xfff5ca25),Color(0xff0b1016),{'name':'Chris junior donald','accountId':'1004586321','balance':300000,'btc':'0.05123456'},avatar:Rect.fromLTWH(30,116,84,84)),
  SceneSpec('cooperativa','cooperativa','Cooperativa','Conta e cartões','cooperativa.jpg',Color(0xff438d13),Color(0xfffafafa),{'balance':502247}),
];
const fieldLabels = {'name':'Nome','balance':'Saldo disponível','scheduled':'Valor agendado',
  'receivable':'Vendas a receber','loan':'Oferta demonstrativa','invoice':'Fatura atual',
  'recipient':'Destinatário demonstrativo','amount':'Valor da transação','accountId':'ID de exibição','btc':'Equivalente em BTC'};

class SceneRecord extends ChangeNotifier {
  final SceneSpec spec;
  final SharedPreferences prefs;
  late Map<String, Object> values;
  String? encodedPhoto;
  bool hidden = false;
  SceneRecord(this.spec, this.prefs) {
    values = Map.of(spec.defaults);
    try {
      final raw = prefs.getString('scene.${spec.id}');
      if (raw != null) {
        final saved = jsonDecode(raw) as Map<String, dynamic>;
        final fields = saved['values'] as Map<String, dynamic>;
        for (final key in values.keys.toList()) {
          final v = fields[key];
          if ((values[key] is int && v is int && v >= 0) || (values[key] is String && v is String)) values[key] = v as Object;
        }
        encodedPhoto = saved['photo'] as String?;
        hidden = saved['hidden'] == true;
      }
    } catch (_) { /* Keep reference values if local data is invalid. */ }
  }
  int cents(String key) => values[key] as int? ?? 0;
  String text(String key) => values[key]?.toString() ?? '';
  Uint8List? get photo { try { return encodedPhoto == null ? null : base64Decode(encodedPhoto!); } catch (_) { return null; } }
  Future<void> save(Map<String,Object> next, String? photo, {bool? hide}) async {
    final h = hide ?? hidden;
    if (!await prefs.setString('scene.${spec.id}', jsonEncode({'values':next,'photo':photo,'hidden':h}))) throw Exception('Falha ao salvar');
    values = Map.of(next); encodedPhoto = photo; hidden = h; notifyListeners();
  }
  Future<void> toggle() => save(values, encodedPhoto, hide: !hidden);
}

final _artCache = <String, Future<ui.Image>>{};
Future<ui.Image> referenceFor(String asset) => _artCache.putIfAbsent(asset, () async {
  final bytes = await rootBundle.load('assets/$asset');
  final codec = await ui.instantiateImageCodec(bytes.buffer.asUint8List());
  final image = (await codec.getNextFrame()).image; codec.dispose(); return image;
});
class ReferenceArt extends StatelessWidget {
  final String asset;
  final Rect source;
  final double width, height;
  const ReferenceArt(this.asset, this.source, {super.key, required this.width, required this.height});
  @override Widget build(BuildContext context) => SizedBox(width:width,height:height,
    child: FutureBuilder<ui.Image>(future: referenceFor(asset), builder:(context,snapshot) => CustomPaint(painter:_Art(snapshot.data,source))));
}
class _Art extends CustomPainter {
  final ui.Image? image;
  final Rect source;
  _Art(this.image,this.source);
  @override void paint(Canvas canvas,Size size) {
    if(image!=null) canvas.drawImageRect(image!,source,Offset.zero & size,Paint()..filterQuality=FilterQuality.high);
  }
  @override bool shouldRepaint(covariant _Art old) => old.image!=image || old.source!=source;
}
class SceneAvatar extends StatelessWidget {
  final SceneRecord record;
  final double size;
  const SceneAvatar({super.key, required this.record,this.size=48});
  @override Widget build(BuildContext context) => ClipOval(child: SizedBox.square(dimension:size,
    child: record.photo!=null ? Image.memory(record.photo!,fit:BoxFit.cover)
    : record.spec.avatar!=null ? ReferenceArt(record.spec.asset,record.spec.avatar!,width:size,height:size)
    : ColoredBox(color:Colors.white,child:Center(child:Text(record.text('name').split(' ').where((s)=>s.isNotEmpty).take(2).map((s)=>s[0]).join(),style:TextStyle(color:Colors.black,fontSize:size*.35,fontWeight:FontWeight.w300))))));
}

Future<void> editScene(BuildContext context,SceneRecord record) => Navigator.push<void>(context,
  MaterialPageRoute(builder:(_)=>SceneEditor(record:record)));
class SceneEditor extends StatefulWidget {
  final SceneRecord record;
  const SceneEditor({super.key,required this.record});
  @override State<SceneEditor> createState()=>_SceneEditorState();
}
class _SceneEditorState extends State<SceneEditor> {
  final form=GlobalKey<FormState>();
  late final controllers={for(final e in widget.record.values.entries) e.key:TextEditingController(text:e.value is int ? money(e.value as int).replaceFirst('R\$ ','') : e.value.toString())};
  late String? photo=widget.record.encodedPhoto;
  bool busy=false;
  @override void dispose(){ for(final c in controllers.values)c.dispose();super.dispose(); }
  Future<void> pick() async {
    setState(()=>busy=true);
    try {
      final file=await ImagePicker().pickImage(source:ImageSource.gallery,maxWidth:800,maxHeight:800,imageQuality:88);
      if(file!=null){final bytes=await file.readAsBytes();if(bytes.length>5*1024*1024)throw Exception();final codec=await ui.instantiateImageCodec(bytes);final frame=await codec.getNextFrame();frame.image.dispose();codec.dispose();if(mounted)setState(()=>photo=base64Encode(bytes));}
    }catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Não foi possível abrir a imagem.')));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> save()async{
    if(!form.currentState!.validate())return;setState(()=>busy=true);
    final next=<String,Object>{for(final e in controllers.entries)e.key:widget.record.values[e.key] is int?parseMoney(e.value.text)!:e.value.text.trim()};
    try{await widget.record.save(next,photo);if(mounted)Navigator.pop(context);}catch(_){if(mounted){setState(()=>busy=false);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Não foi possível salvar.')));}}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('Editar · ${widget.record.spec.title}')),
    body:Form(key:form,child:ListView(padding:const EdgeInsets.all(24),children:[
      Text(widget.record.spec.variant,style:const TextStyle(fontSize:26,fontWeight:FontWeight.w600)),
      const SizedBox(height:8),const Text('As alterações ficam salvas somente neste estudo.'),const SizedBox(height:24),
      if(widget.record.spec.avatar!=null)...[
        Center(child:photo==null?ClipOval(child:ReferenceArt(widget.record.spec.asset,widget.record.spec.avatar!,width:88,height:88)):ClipOval(child:Image.memory(base64Decode(photo!),width:88,height:88,fit:BoxFit.cover))),
        TextButton.icon(onPressed:busy?null:pick,icon:const Icon(Icons.add_photo_alternate_outlined),label:const Text('Trocar foto')),
        if(photo!=null)TextButton(onPressed:busy?null:()=>setState(()=>photo=null),child:const Text('Usar foto da referência')),
      ],
      for(final e in controllers.entries)Padding(padding:const EdgeInsets.only(bottom:18),child:TextFormField(
        key:Key('scene-${e.key}'),controller:e.value,enabled:!busy,
        maxLength:widget.record.values[e.key] is String?80:null,
        keyboardType:widget.record.values[e.key] is int?const TextInputType.numberWithOptions(decimal:true):TextInputType.text,
        decoration:InputDecoration(labelText:fieldLabels[e.key]??e.key,helperText:widget.record.values[e.key] is int?'Formato: 1.234,56':null),
        validator:(v){if(widget.record.values[e.key] is int)return parseMoney(v??'')==null?'Informe um valor válido.':null;return v==null||v.trim().isEmpty?'Preencha este campo.':null;},
      )),
      FilledButton(key:const Key('scene-save'),onPressed:busy?null:save,child:Text(busy?'Salvando…':'Salvar alterações')),
    ])));
}
