import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart' show Home, EditProfile;
import 'model.dart';
import 'bb.dart';
import 'hub.dart' show BrandOpening;
import 'scenes.dart';
import 'scene_screens.dart';

const editionFamily = String.fromEnvironment('STUDY_FAMILY', defaultValue:'all');
class CatalogHome extends StatefulWidget {
  final Profile profile;
  const CatalogHome({super.key,required this.profile});
  @override State<CatalogHome> createState()=>_CatalogHomeState();
}
class _CatalogHomeState extends State<CatalogHome> {
  bool realistic=false;
  String filter='Todas';
  String query='';
  late final bb=BBProfile(widget.profile.prefs);
  final records=<String,SceneRecord>{};
  List<SceneSpec> get available=>sceneSpecs.where((s)=>editionFamily=='all'||s.family==editionFamily).toList();
  void enter(SceneSpec spec){
    widget.profile.realistic=realistic;
    final rec=records.putIfAbsent(spec.id,()=>SceneRecord(spec,widget.profile.prefs));
    Widget buildScreen()=>spec.id=='nu-classico'?Home(profile:widget.profile):spec.id=='bb'?BBHome(profile:bb,realistic:true):ReferenceScreen(record:rec);
    void edit(BuildContext context){
      if(spec.id=='nu-classico'){Navigator.push(context,MaterialPageRoute(builder:(_)=>EditProfile(profile:widget.profile)));}
      else if(spec.id=='bb'){Navigator.push(context,MaterialPageRoute(builder:(_)=>BBPage(child:BBEditor(profile:bb))));}
      else{editScene(context,rec);}
    }
    final target=StudioSession(spec:spec,initialRealistic:realistic,screen:buildScreen,onEdit:edit);
    final Widget route=!realistic?target:spec.family=='nubank'||spec.family=='bb'
      ?BrandOpening(bankBB:spec.family=='bb',target:target):InstitutionOpening(spec:spec,target:target);
    Navigator.push(context,MaterialPageRoute(builder:(_)=>route));
  }
  @override void dispose(){for(final r in records.values)r.dispose();bb.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final families=available.map((s)=>s.family).toSet().toList();
    return AnnotatedRegion<SystemUiOverlayStyle>(value:const SystemUiOverlayStyle(statusBarColor:Color(0xff111219),statusBarIconBrightness:Brightness.light,systemNavigationBarColor:Color(0xff111219)),child:Scaffold(backgroundColor:const Color(0xff111219),body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(22,24,22,32),children:[
      const Row(children:[Icon(Icons.grid_view_rounded,color:Color(0xffd3c0ff)),SizedBox(width:10),Text('ATELIÊ / 02',style:TextStyle(letterSpacing:3,fontSize:12,color:Color(0xffd3c0ff))),Spacer(),Icon(Icons.auto_awesome_outlined,color:Color(0xffd3c0ff),size:20)]),
      const SizedBox(height:28),const Text('Um catálogo.\nMuitos detalhes.',style:TextStyle(fontSize:38,height:1.08,letterSpacing:-1.3,fontWeight:FontWeight.w600)),const SizedBox(height:14),
      Text('${families.length} instituições · ${available.length} referências interativas',style:const TextStyle(color:Color(0xffaaa6b8),fontSize:15)),
      const SizedBox(height:24),SegmentedButton<bool>(key:const Key('study-mode'),segments:const [ButtonSegment(value:false,label:Text('Estudo'),icon:Icon(Icons.tune)),ButtonSegment(value:true,label:Text('Realista'),icon:Icon(Icons.fullscreen))],selected:{realistic},onSelectionChanged:(s)=>setState(()=>realistic=s.first)),
      const SizedBox(height:12),Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:const Color(0xff1d1e29),borderRadius:BorderRadius.circular(14)),child:Text(realistic?'INTERFACE LIMPA\nAbertura da marca e tela sem ferramentas. Segure uma área livre para abrir os controles.':'BANCADA DE ESTUDO\nEditor sempre acessível e comparação lado a lado com o print original.',style:const TextStyle(fontSize:13,height:1.6,color:Color(0xffc6c0d4)))),
      const SizedBox(height:20),TextField(onChanged:(v)=>setState(()=>query=v.toLowerCase()),decoration:InputDecoration(hintText:'Buscar instituição ou variante',prefixIcon:const Icon(Icons.search),filled:true,fillColor:const Color(0xff1b1c26),border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))),
      const SizedBox(height:12),SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:['Todas','Escuras','Claras','Com foto'].map((label)=>Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(label),selected:filter==label,onSelected:(_)=>setState(()=>filter=label)))).toList())),
      const SizedBox(height:20),
      for(final family in families)familyCard(family),
      const SizedBox(height:8),const Text('Referências preservadas',style:TextStyle(fontSize:16,fontWeight:FontWeight.w600)),const SizedBox(height:8),
      const Text('Os prints orientam cada variante. Aberturas de marca e telas não mostradas nas referências são aproximações. “Cooperativa” é um nome descritivo: a instituição não está identificada no recorte.',style:TextStyle(color:Color(0xffaaa6b8),fontSize:13,height:1.5)),
      const SizedBox(height:10),const Text('Projeto independente, sem fins lucrativos. Sem acesso a contas reais.',style:TextStyle(color:Color(0xff777485),fontSize:12)),
    ]))));
  }
  Widget familyCard(String family){
    final variants=available.where((s)=>s.family==family).where((s)=>('${s.title} ${s.variant}'.toLowerCase().contains(query))&&(filter=='Todas'||filter=='Escuras'&&!s.light||filter=='Claras'&&s.light||filter=='Com foto'&&(s.avatar!=null||s.id=='nu-classico'))).toList();
    if(variants.isEmpty)return const SizedBox.shrink();
    final first=variants.first;
    return Padding(padding:const EdgeInsets.only(bottom:16),child:Material(color:const Color(0xff1b1c25),borderRadius:BorderRadius.circular(21),clipBehavior:Clip.antiAlias,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      InkWell(key:Key(family=='nubank'?'enter-nubank':'enter-$family'),onTap:()=>enter(first),child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[
        Container(width:6,height:74,decoration:BoxDecoration(color:first.accent,borderRadius:BorderRadius.circular(4))),const SizedBox(width:14),
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(first.title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w600)),const SizedBox(height:7),Text('${variants.length} ${variants.length==1?'referência':'referências'} · ${realistic?'modo realista':'modo estudo'}',style:const TextStyle(color:Color(0xffa5a1b4),fontSize:12)),const SizedBox(height:10),Text('ABRIR ${first.variant.toUpperCase()}',style:TextStyle(color:first.accent,fontSize:10,letterSpacing:1))])),
        const SizedBox(width:8),const Icon(Icons.north_east,color:Color(0xffbfb7cf)),
      ]))),
      if(variants.length>1)Padding(padding:const EdgeInsets.fromLTRB(18,0,18,16),child:Wrap(spacing:7,runSpacing:7,children:variants.map((s)=>ActionChip(key:Key('variant-${s.id}'),avatar:Icon(s.light?Icons.light_mode_outlined:Icons.dark_mode_outlined,size:15),label:Text(s.variant,style:const TextStyle(fontSize:11)),onPressed:()=>enter(s))).toList())),
    ])));
  }
}

class StudioSession extends StatefulWidget {
  final SceneSpec spec;
  final bool initialRealistic;
  final Widget Function() screen;
  final void Function(BuildContext) onEdit;
  const StudioSession({super.key,required this.spec,required this.initialRealistic,required this.screen,required this.onEdit});
  @override State<StudioSession> createState()=>_StudioSessionState();
}
class _StudioSessionState extends State<StudioSession> {
  late bool realistic=widget.initialRealistic;
  void controls()=>showModalBottomSheet<void>(context:context,showDragHandle:true,builder:(sheet)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[
    ListTile(leading:const Icon(Icons.tune),title:const Text('Abrir bancada de estudo'),onTap:(){Navigator.pop(sheet);setState(()=>realistic=false);}),
    ListTile(leading:const Icon(Icons.edit_outlined),title:const Text('Editar dados'),onTap:(){Navigator.pop(sheet);widget.onEdit(context);}),
    ListTile(leading:const Icon(Icons.grid_view),title:const Text('Voltar ao catálogo'),onTap:()=>Navigator.popUntil(context,(r)=>r.isFirst)),
  ])));
  void compare()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ComparisonPage(spec:widget.spec,screen:widget.screen)));
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xff171821),body:Column(children:[
    if(!realistic)SafeArea(bottom:false,child:Container(key:const Key('study-toolbar'),padding:const EdgeInsets.fromLTRB(12,6,12,8),decoration:BoxDecoration(border:Border(bottom:BorderSide(color:widget.spec.accent,width:2))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[IconButton(tooltip:'Catálogo',onPressed:()=>Navigator.popUntil(context,(r)=>r.isFirst),icon:const Icon(Icons.arrow_back,size:20)),Expanded(child:Text('ESTUDO · ${widget.spec.title}',style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600,letterSpacing:1))),Text(widget.spec.variant,style:const TextStyle(color:Colors.grey,fontSize:10))]),
      Wrap(spacing:8,children:[ActionChip(label:const Text('Editar'),avatar:const Icon(Icons.edit_outlined,size:16),onPressed:()=>widget.onEdit(context)),ActionChip(key:const Key('compare-study'),label:const Text('Comparar'),avatar:const Icon(Icons.compare,size:16),onPressed:compare),ActionChip(key:const Key('clean-mode'),label:const Text('Realista'),avatar:const Icon(Icons.fullscreen,size:16),onPressed:()=>setState(()=>realistic=true))]),
    ]))),
    Expanded(child:GestureDetector(behavior:HitTestBehavior.translucent,onLongPress:realistic?controls:null,child:MediaQuery.removePadding(context:context,removeTop:!realistic,child:widget.screen()))),
  ]));
}
class ComparisonPage extends StatelessWidget {
  final SceneSpec spec;
  final Widget Function() screen;
  const ComparisonPage({super.key,required this.spec,required this.screen});
  @override Widget build(BuildContext context){
    final width=MediaQuery.sizeOf(context).width;
    return Scaffold(appBar:AppBar(title:const Text('Comparar referência')),body:ListView(padding:const EdgeInsets.all(12),children:[
      const Text('O print enviado à esquerda; a interface interativa à direita.',style:TextStyle(color:Colors.grey,fontSize:13)),const SizedBox(height:16),
      Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Expanded(child:Column(children:[const Text('REFERÊNCIA',style:TextStyle(fontSize:10,letterSpacing:1)),const SizedBox(height:8),Image.asset('assets/${spec.asset}',fit:BoxFit.contain)])),const SizedBox(width:8),
        Expanded(child:Column(children:[const Text('REPRODUÇÃO',style:TextStyle(fontSize:10,letterSpacing:1)),const SizedBox(height:8),SizedBox(height:(width-32)/2*1.9,child:FittedBox(alignment:Alignment.topCenter,fit:BoxFit.contain,child:SizedBox(width:432,height:821,child:MediaQuery(data:const MediaQueryData(size:Size(432,821)),child:screen()))))])),
      ]),const SizedBox(height:20),const Text('A rolagem e os controles da reprodução continuam disponíveis. Recortes, barras do sistema e fontes do aparelho podem alterar o enquadramento.',style:TextStyle(color:Colors.grey,fontSize:12,height:1.5)),
    ]));
  }
}
class InstitutionOpening extends StatefulWidget {
  final SceneSpec spec;
  final Widget target;
  const InstitutionOpening({super.key,required this.spec,required this.target});
  @override State<InstitutionOpening> createState()=>_InstitutionOpeningState();
}
class _InstitutionOpeningState extends State<InstitutionOpening> {
  @override void initState(){super.initState();Future<void>.delayed(const Duration(milliseconds:1100),(){if(mounted)Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>widget.target));});}
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:widget.spec.family=='next'||widget.spec.family=='binance'?Colors.black:widget.spec.accent,body:Center(child:Text(widget.spec.title,style:TextStyle(fontSize:42,fontWeight:FontWeight.w700,color:widget.spec.family=='next'||widget.spec.family=='binance'?widget.spec.accent:Colors.white))));
}
