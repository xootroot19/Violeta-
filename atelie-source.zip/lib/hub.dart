// Nubank vector mark: https://github.com/simple-icons/simple-icons/blob/develop/icons/nubank.svg
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'catalog.dart';
import 'model.dart';
import 'bb.dart';

class StudyNotice extends StatelessWidget {
  final Profile profile;
  const StudyNotice({super.key, required this.profile});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xff15121d),
    body: SafeArea(child: LayoutBuilder(builder: (context, constraints) => SingleChildScrollView(
      padding: const EdgeInsets.all(28),
      child: ConstrainedBox(constraints: BoxConstraints(minHeight: (constraints.maxHeight - 56).clamp(0.0, double.infinity).toDouble()),
        child: IntrinsicHeight(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 32), const Icon(Icons.auto_awesome_mosaic_outlined, size: 48, color: Color(0xffcebbff)),
          const Spacer(), const SizedBox(height: 36),
          const Text('Interfaces\nem estudo.', style: TextStyle(fontSize: 43, height: 1.12, fontWeight: FontWeight.w600, letterSpacing: -1.5)),
          const SizedBox(height: 24),
          const Text('Projeto independente e sem fins lucrativos.', style: TextStyle(fontSize: 21, height: 1.4)),
          const SizedBox(height: 16),
          const Text('Reproduções para estudar design e interações. Sem vínculo com as instituições retratadas. Os valores são editáveis e as operações são apenas demonstrações.',
            style: TextStyle(fontSize: 16, height: 1.6, color: Color(0xffbdb6ca))),
          const SizedBox(height: 16),
          const Text('Modo Estudo: editor e comparação com a referência. Modo Realista: interface limpa com identidade visual. Ambos são demonstrações, sem acesso a contas reais.',
            style: TextStyle(fontSize: 14, height: 1.6, color: Color(0xffbdb6ca))),
          const SizedBox(height: 36), const Spacer(),
          SizedBox(width: double.infinity, height: 56, child: FilledButton(
            onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => StudyHub(profile: profile))),
            child: const Text('Explorar o estudo', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)))),
          const SizedBox(height: 12),
        ])),
      ),
    ))),
  );
}

class StudyHub extends StatefulWidget {
  final Profile profile;
  const StudyHub({super.key, required this.profile});
  @override State<StudyHub> createState() => _StudyHubState();
}
class _StudyHubState extends State<StudyHub> {
  @override Widget build(BuildContext context) => CatalogHome(profile: widget.profile);
}

class BrandOpening extends StatefulWidget {
  final bool bankBB;
  final Widget target;
  const BrandOpening({super.key, required this.bankBB, required this.target});
  @override State<BrandOpening> createState() => _BrandOpeningState();
}
class _BrandOpeningState extends State<BrandOpening> {
  Timer? timer;
  @override void initState() {
    super.initState();
    timer = Timer(const Duration(milliseconds: 1400), () {
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => widget.target));
    });
  }
  @override void dispose() { timer?.cancel(); super.dispose(); }
  @override Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
    value: SystemUiOverlayStyle(statusBarColor: widget.bankBB ? bbHeader : const Color(0xff820ad1), statusBarIconBrightness: Brightness.light),
    child: Scaffold(backgroundColor: widget.bankBB ? bbHeader : const Color(0xff820ad1),
      body: Center(child: widget.bankBB
        ? Column(mainAxisSize: MainAxisSize.min, children: [
            const BBArt(Rect.fromLTWH(38,81,57,58), width: 82, height: 84), const SizedBox(height: 24),
            const Text('Banco do Brasil', style: TextStyle(fontSize: 22, color: Colors.yellow, fontWeight: FontWeight.w600)),
          ])
        : SvgPicture.asset('assets/nubank.svg', width: 115, height: 88,
            colorFilter: const ColorFilter.mode(Colors.white, BlendMode.srcIn))),
    ),
  );
}
