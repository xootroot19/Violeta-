import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

String money(int cents) {
  final digits = (cents.abs() ~/ 100).toString();
  final whole = digits.replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');
  return '${cents < 0 ? '-' : ''}R\$ $whole,${(cents.abs() % 100).toString().padLeft(2, '0')}';
}
int? parseMoney(String text) {
  final clean = text.replaceAll('R\$', '').replaceAll(' ', '').trim();
  if (!RegExp(r'^\d{1,3}(\.\d{3})*(,\d{1,2})?$|^\d+(,\d{1,2})?$').hasMatch(clean)) return null;
  final parts = clean.replaceAll('.', '').split(',');
  final value = int.tryParse(parts[0]);
  if (value == null || value > 999999999) return null;
  return value * 100 + (parts.length == 2 ? int.parse(parts[1].padRight(2, '0')) : 0);
}

class Profile extends ChangeNotifier {
  bool realistic = false;
  final SharedPreferences prefs;
  String name;
  int balance;
  Uint8List? photo;
  bool hidden;
  Profile(this.prefs)
      : name = prefs.getString('name') ?? 'Gustavo',
        balance = prefs.getInt('balance') ?? 58844449,
        hidden = prefs.getBool('hidden') ?? false {
    final encoded = prefs.getString('photo');
    if (encoded != null) {
      try { photo = base64Decode(encoded); } catch (_) { photo = null; }
    }
  }
  Future<void> update(String nextName, int nextBalance, Uint8List? nextPhoto) async {
    // One snapshot ensures profile values stay consistent across restarts.
    final snapshot = jsonEncode({'name': nextName, 'balance': nextBalance,
      'photo': nextPhoto == null ? null : base64Encode(nextPhoto)});
    if (!await prefs.setString('profile', snapshot)) throw Exception('Falha ao salvar');
    name = nextName; balance = nextBalance; photo = nextPhoto;
    notifyListeners();
  }
  void restoreSnapshot() {
    final raw = prefs.getString('profile');
    if (raw == null) return;
    try {
      final p = jsonDecode(raw) as Map<String, dynamic>;
      name = p['name'] as String; balance = p['balance'] as int;
      photo = p['photo'] == null ? null : base64Decode(p['photo'] as String);
    } catch (_) { /* Keep defaults for an invalid local snapshot. */ }
  }
  Future<void> toggleHidden() async {
    final value = !hidden;
    if (!await prefs.setBool('hidden', value)) throw Exception('Falha ao salvar');
    hidden = value; notifyListeners();
  }
}
