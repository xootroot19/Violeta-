import 'dart:convert';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'model.dart';

const bbBlue = Color(0xff2057f7);
const bbHeader = Color(0xff354df7);
const bbPaper = Color(0xfffcfefe);
ui.Image? bbReference;

class BBProfile extends ChangeNotifier {
  final SharedPreferences prefs;
  String name = 'Vitoria';
  int balance = 50000000000;
  int scheduled = 0;
  String until = '31/Dez';
  bool hidden = false;
  BBProfile(this.prefs) {
    final raw = prefs.getString('bb-profile');
    if (raw != null) {
      try {
        final data = jsonDecode(raw) as Map<String, dynamic>;
        name = data['name'] as String;
        balance = data['balance'] as int;
        scheduled = data['scheduled'] as int;
        until = data['until'] as String;
        hidden = data['hidden'] as bool;
      } catch (_) { /* Preserve the reference defaults for invalid local data. */ }
    }
  }
  Future<void> save(String n, int b, int s, String date, {bool? hide}) async {
    final nextHidden = hide ?? hidden;
    final ok = await prefs.setString('bb-profile', jsonEncode({
      'name': n, 'balance': b, 'scheduled': s, 'until': date, 'hidden': nextHidden,
    }));
    if (!ok) throw Exception('Não foi possível salvar');
    name = n; balance = b; scheduled = s; until = date; hidden = nextHidden;
    notifyListeners();
  }
}

// Reference artwork is drawn into independent interactive widgets. Names,
// amounts, navigation and forms are native Flutter widgets, not a full-screen image.
class BBArt extends StatelessWidget {
  final Rect source;
  final double width;
  final double height;
  const BBArt(this.source, {super.key, required this.width, required this.height});
  @override
  Widget build(BuildContext context) => SizedBox(width: width, height: height,
    child: CustomPaint(painter: _ReferencePainter(source)));
}
class _ReferencePainter extends CustomPainter {
  final Rect source;
  _ReferencePainter(this.source);
  @override
  void paint(Canvas canvas, Size size) {
    if (bbReference != null) {
      canvas.drawImageRect(bbReference!, source, Offset.zero & size,
        Paint()..filterQuality = FilterQuality.high);
    }
  }
  @override
  bool shouldRepaint(covariant _ReferencePainter old) => source != old.source;
}

class BBHome extends StatefulWidget {
  final BBProfile profile;
  final bool realistic;
  const BBHome({super.key, required this.profile, this.realistic = false});
  @override
  State<BBHome> createState() => _BBHomeState();
}
class _BBHomeState extends State<BBHome> {
  int tab = 1;
  int banner = 3;
  final pages = PageController(initialPage: 3, viewportFraction: .90);
  final search = TextEditingController();
  BBProfile get p => widget.profile;
  static const labels = ['Extrato', 'Pagamento', 'Transferência', 'Pix',
    'Empréstimo', 'Seguro', 'Investimento', 'Consórcio'];
  @override
  void dispose() { pages.dispose(); search.dispose(); super.dispose(); }
  void hub() => Navigator.of(context).popUntil((route) => route.isFirst);
  Future<void> edit() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => BBPage(child: BBEditor(profile: p))));
  }
  void feature(String title) => Navigator.push(context, MaterialPageRoute(
    builder: (_) => BBPage(child: BBFeature(title: title, profile: p))));
  Future<void> toggle() async {
    try { await p.save(p.name, p.balance, p.scheduled, p.until, hide: !p.hidden); }
    catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível salvar.'))); }
  }
  @override
  Widget build(BuildContext context) => Theme(
    data: ThemeData(useMaterial3: true, brightness: Brightness.light,
      scaffoldBackgroundColor: bbPaper, fontFamily: 'Roboto',
      colorScheme: ColorScheme.fromSeed(seedColor: bbBlue, brightness: Brightness.light)),
    child: AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(statusBarColor: bbBlue, statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: bbPaper, systemNavigationBarIconBrightness: Brightness.dark),
      child: ListenableBuilder(listenable: p, builder: (context, _) => Scaffold(
        backgroundColor: bbPaper,
        body: Column(children: [header(context), Expanded(child: tab == 1 ? home(context) : secondary(context))]),
        bottomNavigationBar: navigation(context),
      )),
    ),
  );
  Widget header(BuildContext context) {
    final scale = MediaQuery.sizeOf(context).width / 432;
    return Container(color: bbHeader, padding: EdgeInsets.only(top: MediaQuery.paddingOf(context).top),
      child: Padding(padding: EdgeInsets.symmetric(horizontal: 12 * scale, vertical: 10 * scale),
        child: Row(children: [
          Tooltip(message: 'Hub de estudos', child: InkWell(onTap: hub,
            child: SizedBox(width: 44 * scale, height: 44 * scale, child: Center(child: widget.realistic
              ? BBArt(const Rect.fromLTWH(38, 81, 57, 58), width: 29 * scale, height: 29 * scale)
              : Text('B', style: TextStyle(color: const Color(0xffffef00), fontSize: 31 * scale, fontWeight: FontWeight.w800)))))),
          Expanded(child: InkWell(onTap: edit, child: Text('Olá, ${p.name}',
            style: TextStyle(color: Colors.white, fontSize: 22 * scale, fontWeight: FontWeight.w500), maxLines: 2))),
          IconButton(tooltip: p.hidden ? 'Mostrar valores BB' : 'Ocultar valores BB', onPressed: toggle,
            icon: Icon(p.hidden ? Icons.visibility_off : Icons.visibility, color: Colors.white, size: 28 * scale)),
          IconButton(tooltip: 'Mensagens', onPressed: () => feature('Mensagens'),
            icon: Icon(Icons.chat, color: Colors.white, size: 28 * scale)),
          IconButton(tooltip: 'Sair para o hub', onPressed: hub,
            icon: Icon(Icons.logout, color: Colors.white, size: 28 * scale)),
        ])));
  }
  Widget home(BuildContext context) {
    final s = MediaQuery.sizeOf(context).width / 432;
    return ListView(padding: EdgeInsets.zero, children: [
      Padding(padding: EdgeInsets.fromLTRB(18 * s, 18 * s, 18 * s, 0),
        child: InkWell(onTap: edit, child: Container(
          padding: EdgeInsets.symmetric(horizontal: 18 * s, vertical: 18 * s),
          decoration: BoxDecoration(color: const Color(0xffeff1fd), borderRadius: BorderRadius.circular(5 * s)),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: 6, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Saldo disponível', style: TextStyle(color: const Color(0xff858585), fontSize: 16 * s)),
              const SizedBox(height: 3),
              FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
                child: Text(p.hidden ? 'R\$ ••••••' : money(p.balance), style: TextStyle(color: bbBlue, fontSize: 22 * s, fontWeight: FontWeight.w700))),
            ])),
            const SizedBox(width: 8),
            Expanded(flex: 5, child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              FittedBox(fit: BoxFit.scaleDown, child: Text('Agendado até ${p.until}', style: TextStyle(color: const Color(0xff858585), fontSize: 16 * s))),
              const SizedBox(height: 3),
              FittedBox(fit: BoxFit.scaleDown, child: Text(p.hidden ? 'R\$ ••••••' : money(p.scheduled), style: TextStyle(color: bbBlue, fontSize: 22 * s, fontWeight: FontWeight.w700))),
            ])),
          ])))),
      SizedBox(height: 27 * s),
      for (int row = 0; row < 2; row++) Padding(
        padding: EdgeInsets.fromLTRB(18 * s, 0, 18 * s, 19 * s),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: List.generate(4, (col) {
          final i = row * 4 + col;
          return Expanded(child: InkWell(onTap: () => feature(labels[i]),
            borderRadius: BorderRadius.circular(34),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ClipOval(child: BBArt(Rect.fromLTWH(70 + col * 198.0, 437 + row * 208.0, 132, 132), width: 66 * s, height: 66 * s)),
              SizedBox(height: 6 * s),
              Text(labels[i], textAlign: TextAlign.center, style: TextStyle(color: const Color(0xff161616), fontSize: 14 * s)),
            ])));
        }))),
      Padding(padding: EdgeInsets.fromLTRB(18 * s, 25 * s, 18 * s, 16 * s),
        child: Text(widget.realistic ? 'Loja BB' : 'Loja Estudo', style: TextStyle(fontSize: 27 * s, color: const Color(0xff141414), fontWeight: FontWeight.w700))),
      SizedBox(height: 158 * s, child: PageView.builder(controller: pages,
        onPageChanged: (value) => setState(() => banner = value), itemCount: 4,
        itemBuilder: (context, i) => Padding(padding: EdgeInsets.symmetric(horizontal: 4 * s),
          child: InkWell(onTap: () => feature('Loja BB'), child: ClipRRect(borderRadius: BorderRadius.circular(10 * s),
            child: i == 3 ? BBArt(const Rect.fromLTWH(53, 1003, 760, 315), width: 380 * s, height: 158 * s)
              : Container(color: [const Color(0xff262a30), const Color(0xffeeeb7d), const Color(0xff43d7ef)][i],
                  padding: EdgeInsets.all(24 * s), alignment: Alignment.centerLeft,
                  child: Text(['Vantagens para o seu dia.', 'Novas possibilidades.', 'Explore a Loja BB.'][i],
                    style: TextStyle(fontSize: 27 * s, fontWeight: FontWeight.w700, color: i == 0 ? Colors.white : bbBlue)))))))),
      Padding(padding: EdgeInsets.symmetric(vertical: 10 * s), child: Row(mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(4, (i) => Semantics(button: true, label: 'Oferta ${i + 1}', selected: banner == i,
          child: GestureDetector(onTap: () => pages.animateToPage(i, duration: const Duration(milliseconds: 220), curve: Curves.easeOut),
            child: Container(margin: const EdgeInsets.symmetric(horizontal: 5), height: 7 * s,
              width: (banner == i ? 27 : 7) * s, decoration: BoxDecoration(color: banner == i ? bbBlue : const Color(0xffe0e3e5), borderRadius: BorderRadius.circular(8)))))))),
      Padding(padding: EdgeInsets.all(18 * s), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [Icons.credit_card, Icons.savings, Icons.phone_android, Icons.favorite].map((icon) => IconButton(
          onPressed: () => feature('Benefícios'), icon: Icon(icon, color: bbBlue), style: IconButton.styleFrom(backgroundColor: const Color(0xffeff1fd), padding: EdgeInsets.all(20 * s)))).toList())),
    ]);
  }
  Widget navigation(BuildContext context) {
    const names = ['Menu', 'Início', 'Busca', 'Notificações', 'Perfil'];
    const icons = [Icons.menu, Icons.home, Icons.search, Icons.notifications, Icons.person];
    return SafeArea(top: false, child: Container(color: bbPaper, child: Row(crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(5, (i) => Expanded(child: Semantics(selected: tab == i, button: true,
        child: InkWell(onTap: () { if (i == 4) { edit(); } else { setState(() => tab = i); } },
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(height: 4, color: tab == i ? bbBlue : Colors.transparent),
            const SizedBox(height: 8),
            Stack(clipBehavior: Clip.none, children: [Icon(icons[i], color: tab == i ? bbBlue : const Color(0xff888b8e), size: 27),
              if (i == 3) Positioned(top: -9, right: -10, child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: Colors.yellow, borderRadius: BorderRadius.circular(15)),
                child: const Text('99+', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700))))]),
            const SizedBox(height: 2),
            Padding(padding: const EdgeInsets.only(bottom: 9), child: Text(names[i], textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: tab == i ? bbBlue : const Color(0xff858585)))),
          ]))))))));
  }
  Widget secondary(BuildContext context) {
    if (tab == 2) return ListView(padding: const EdgeInsets.all(20), children: [
      TextField(controller: search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'O que você procura?', prefixIcon: Icon(Icons.search))),
      for (final label in labels.where((l) => l.toLowerCase().contains(search.text.toLowerCase())))
        ListTile(title: Text(label), trailing: const Icon(Icons.chevron_right), onTap: () => feature(label)),
    ]);
    if (tab == 3) return ListView(padding: const EdgeInsets.all(20), children: const [
      Text('Notificações', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
      SizedBox(height: 24), ListTile(leading: Icon(Icons.info_outline), title: Text('Bem-vindo ao estudo'), subtitle: Text('Os avisos e a contagem reproduzem a interface de referência.')),
    ]);
    return ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Menu', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
      ListTile(leading: const Icon(Icons.tune), title: const Text('Editar nome e valores'), onTap: edit),
      ListTile(leading: const Icon(Icons.grid_view), title: const Text('Hub de estudos'), onTap: hub),
      for (final label in labels) ListTile(title: Text(label), trailing: const Icon(Icons.chevron_right), onTap: () => feature(label)),
    ]);
  }
}

class BBEditor extends StatefulWidget {
  final BBProfile profile;
  const BBEditor({super.key, required this.profile});
  @override State<BBEditor> createState() => _BBEditorState();
}
class _BBEditorState extends State<BBEditor> {
  final form = GlobalKey<FormState>();
  late final name = TextEditingController(text: widget.profile.name);
  late final balance = TextEditingController(text: money(widget.profile.balance).replaceFirst('R\$ ', ''));
  late final scheduled = TextEditingController(text: money(widget.profile.scheduled).replaceFirst('R\$ ', ''));
  late final until = TextEditingController(text: widget.profile.until);
  bool saving = false;
  @override void dispose() { name.dispose(); balance.dispose(); scheduled.dispose(); until.dispose(); super.dispose(); }
  Future<void> save() async {
    if (!form.currentState!.validate()) return;
    setState(() => saving = true);
    try {
      await widget.profile.save(name.text.trim(), parseMoney(balance.text)!, parseMoney(scheduled.text)!, until.text.trim());
      if (mounted) Navigator.pop(context);
    } catch (_) { if (mounted) { setState(() => saving = false); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível salvar.'))); } }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Personalizar estudo BB')),
    body: Form(key: form, child: ListView(padding: const EdgeInsets.all(24), children: [
      const Text('Como na sua referência', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w600)),
      const SizedBox(height: 12), const Text('Este layout não tem foto de perfil. Personalize o nome e os valores exibidos.'),
      const SizedBox(height: 24),
      TextFormField(key: const Key('bb-name'), controller: name, enabled: !saving, maxLength: 28, decoration: const InputDecoration(labelText: 'Nome'), validator: (v) => v == null || v.trim().isEmpty ? 'Digite o nome.' : null),
      const SizedBox(height: 16),
      for (final entry in [(balance, 'Saldo disponível', 'bb-balance'), (scheduled, 'Valor agendado', 'bb-scheduled')]) ...[
        TextFormField(key: Key(entry.$3), controller: entry.$1, enabled: !saving, keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: entry.$2, prefixText: 'R\$ '), validator: (v) => parseMoney(v ?? '') == null ? 'Informe um valor válido.' : null),
        const SizedBox(height: 16),
      ],
      TextFormField(controller: until, enabled: !saving, maxLength: 12, decoration: const InputDecoration(labelText: 'Agendado até'), validator: (v) => v == null || v.trim().isEmpty ? 'Informe a data de exibição.' : null),
      const SizedBox(height: 24), FilledButton(key: const Key('bb-save'), onPressed: saving ? null : save, child: Text(saving ? 'Salvando…' : 'Salvar alterações')),
    ])));
}

class BBFeature extends StatefulWidget {
  final String title;
  final BBProfile profile;
  const BBFeature({super.key, required this.title, required this.profile});
  @override State<BBFeature> createState() => _BBFeatureState();
}
class _BBFeatureState extends State<BBFeature> {
  final amount = TextEditingController();
  String? error;
  @override void dispose() { amount.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.title)),
    body: ListView(padding: const EdgeInsets.all(24), children: [
      Text(widget.title, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w600)), const SizedBox(height: 20),
      if (widget.title == 'Extrato') ...[
        const Text('Saldo disponível'), const SizedBox(height: 8),
        Text(widget.profile.hidden ? 'R\$ ••••••' : money(widget.profile.balance), style: const TextStyle(fontSize: 26)),
        const SizedBox(height: 30), const Text('Nenhuma movimentação nesta conta demonstrativa.'),
      ] else ...[
        const Text('Interação demonstrativa do estudo. Nenhuma operação financeira é realizada.'), const SizedBox(height: 24),
        TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: 'Valor de demonstração', prefixText: 'R\$ ', errorText: error)),
        const SizedBox(height: 24), FilledButton(onPressed: () {
          final value = parseMoney(amount.text);
          if (value == null || value <= 0) { setState(() => error = 'Digite um valor maior que zero.'); return; }
          setState(() => error = null);
          showDialog<void>(context: context, builder: (dialog) => AlertDialog(title: const Text('Demonstração concluída'),
            content: Text('${money(value)} — nenhum valor foi movimentado.'), actions: [TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('Entendi'))]));
        }, child: const Text('Experimentar')),
      ],
    ]));
}

class BBPage extends StatelessWidget {
  final Widget child;
  const BBPage({super.key, required this.child});
  @override Widget build(BuildContext context) => Theme(
    data: ThemeData(useMaterial3: true, brightness: Brightness.light,
      scaffoldBackgroundColor: bbPaper, fontFamily: 'Roboto',
      colorScheme: ColorScheme.fromSeed(seedColor: bbBlue),
      appBarTheme: const AppBarTheme(backgroundColor: bbPaper, foregroundColor: bbBlue),
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder())),
    child: child,
  );
}
