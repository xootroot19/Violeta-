import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'scenes.dart';
import 'glyph.dart';
import 'model.dart';

class ReferenceScreen extends StatefulWidget {
  final SceneRecord record;
  const ReferenceScreen({super.key,required this.record});
  @override State<ReferenceScreen> createState()=>_ReferenceScreenState();
}
class _ReferenceScreenState extends State<ReferenceScreen> {
  SceneRecord get r=>widget.record;
  SceneSpec get spec=>r.spec;
  int tab=0;
  bool expanded=false;
  double get scale=>MediaQuery.sizeOf(context).width/432;
  Color get foreground=>spec.light?const Color(0xff171717):const Color(0xffeeeeee);
  void edit()=>editScene(context,r);
  void open(String title)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DemoPanel(record:r,title:title)));
  Future<void> hide()async{try{await r.toggle();}catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Não foi possível salvar.')));}}
  Widget text(String value,{double size=16,Color? color,FontWeight weight=FontWeight.w400,TextAlign? align})=>Text(value,textAlign:align,style:TextStyle(fontSize:size*scale,color:color??foreground,fontWeight:weight,height:1.25));
  Widget gap(double h)=>SizedBox(height:h*scale);
  Widget divider()=>Divider(color:spec.light?const Color(0xffededed):const Color(0xff303030),height:1);
  Widget icon(IconData value,String label,VoidCallback action,{Color? color})=>IconButton(tooltip:label,onPressed:action,icon:Icon(value,color:color??foreground,size:26*scale));
  Widget art(Rect rect,{double? width}){final w=width??MediaQuery.sizeOf(context).width-40*scale;return ReferenceArt(spec.asset,rect,width:w,height:w*rect.height/rect.width);}
  Widget banner(Rect rect,String title)=>InkWell(onTap:()=>open(title),child:ClipRRect(borderRadius:BorderRadius.circular(10*scale),child:art(rect)));
  Widget dots({int count=2})=>Padding(padding:EdgeInsets.symmetric(vertical:14*scale),child:Row(mainAxisAlignment:MainAxisAlignment.center,children:List.generate(count,(i)=>Container(width:7*scale,height:7*scale,margin:const EdgeInsets.symmetric(horizontal:4),decoration:BoxDecoration(shape:BoxShape.circle,color:i==tab%count?spec.accent:Colors.grey.shade700)))));
  double labelsHeight(List<String> labels,double width,double size,{FontWeight weight=FontWeight.w400}) {
    double result=0;
    for(final label in labels){
      final painter=TextPainter(text:TextSpan(text:label,style:DefaultTextStyle.of(context).style.merge(TextStyle(fontSize:size*scale,height:1.25,fontWeight:weight))),textDirection:Directionality.of(context),textScaler:MediaQuery.textScalerOf(context))..layout(maxWidth:width);
      if(painter.height>result)result=painter.height;
      painter.dispose();
    }
    return result.ceilToDouble();
  }
  String balance([String key='balance'])=>r.hidden?'R\$ ••••••':money(r.cents(key));
  Widget amount({String keyName='balance',double size=27,Color? color})=>InkWell(onTap:edit,child:FittedBox(fit:BoxFit.scaleDown,alignment:Alignment.centerLeft,child:text(balance(keyName),size:size,color:color,weight:FontWeight.w600)));
  Widget tileAction(Glyph glyph,String label,{Color? color,Color? fill})=>Expanded(child:InkWell(onTap:()=>label=='Pix'&&spec.family=='next'?Navigator.push(context,MaterialPageRoute(builder:(_)=>NextTransfer(record:r))):open(label),child:Column(children:[
    Container(width:54*scale,height:54*scale,decoration:BoxDecoration(shape:BoxShape.circle,color:fill??const Color(0xff262626)),child:Center(child:LineIcon(glyph,size:25*scale,color:color??spec.accent))),gap(10),text(label,size:11,weight:FontWeight.w600,align:TextAlign.center),
  ])));
  @override Widget build(BuildContext context)=>Theme(data:ThemeData(useMaterial3:true,brightness:spec.light?Brightness.light:Brightness.dark,scaffoldBackgroundColor:spec.background,fontFamily:'Roboto',colorScheme:ColorScheme.fromSeed(seedColor:spec.accent,brightness:spec.light?Brightness.light:Brightness.dark)),child:AnnotatedRegion<SystemUiOverlayStyle>(
    value:SystemUiOverlayStyle(statusBarColor:spec.background,statusBarIconBrightness:spec.light?Brightness.dark:Brightness.light,systemNavigationBarColor:spec.background,systemNavigationBarIconBrightness:spec.light?Brightness.dark:Brightness.light),
    child:ListenableBuilder(listenable:r,builder:(context,_)=>spec.id=='next-transferencia'?NextTransfer(record:r):Scaffold(backgroundColor:spec.background,
      body:SafeArea(bottom:false,child:spec.family=='next'?next():spec.family=='nubank'?nu():spec.family=='bradesco'?bradesco():spec.family=='pagbank'?pagbank():spec.family=='binance'?binance():cooperative()),
      bottomNavigationBar:spec.family=='binance'?cryptoNav():spec.family=='nubank'?nuNav():null,
    )),
  ));
  Widget next()=>ListView(padding:EdgeInsets.zero,children:[
    Padding(padding:EdgeInsets.symmetric(horizontal:20*scale),child:Row(children:[icon(Icons.notifications_none,'Notificações',()=>open('Notificações'),color:spec.accent),const Spacer(),text('next',size:26,weight:FontWeight.w700),const Spacer(),TextButton(onPressed:()=>open('Ajuda'),child:text('AJUDA',size:13,weight:FontWeight.w600))])),divider(),
    Padding(padding:EdgeInsets.all(24*scale),child:Row(children:[InkWell(onTap:edit,child:SceneAvatar(record:r,size:50*scale)),SizedBox(width:16*scale),Expanded(child:InkWell(onTap:edit,child:Text(r.text('name'),style:TextStyle(color:Colors.white,fontFamily:spec.id=='next-foto'?'serif':'Roboto',fontSize:(spec.id=='next-foto'?26:17)*scale,fontWeight:spec.id=='next-foto'?FontWeight.w700:FontWeight.w500)))),icon(Icons.settings_outlined,'Editar perfil',edit)])),
    Padding(padding:EdgeInsets.symmetric(horizontal:20*scale),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[divider(),gap(20),text('SALDO CONTA-CORRENTE',size:13,color:Colors.grey),gap(8),Row(children:[Expanded(child:amount(size:28)),icon(r.hidden?Icons.visibility:Icons.visibility_off_outlined,'Alternar saldo',hide)]),gap(28),divider(),gap(16),
      banner(spec.id=='next-foto'?const Rect.fromLTWH(46,594,814,291):const Rect.fromLTWH(40,433,776,281),spec.id=='next-foto'?'Débito automático':'Aplicação em CDB'),dots(),divider(),gap(16),
      Row(crossAxisAlignment:CrossAxisAlignment.start,children:[tileAction(Glyph.barcode,'Extrato'),tileAction(Glyph.pix,'Pix'),tileAction(Glyph.card,'Cartão'),tileAction(Glyph.barcode,'Pagar'),tileAction(Glyph.loan,'Antecipar\nFGTS')]),gap(26),
      Center(child:OutlinedButton(onPressed:()=>setState(()=>expanded=!expanded),style:OutlinedButton.styleFrom(side:const BorderSide(color:Colors.white),foregroundColor:Colors.white),child:Padding(padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),child:Row(mainAxisSize:MainAxisSize.min,children:[text(expanded?'Ver menos':'Ver mais',size:16,weight:FontWeight.w600),const SizedBox(width:8),Icon(expanded?Icons.expand_less:Icons.expand_more)])))),
      if(expanded)...[gap(20),Row(children:[tileAction(Glyph.arrows,'Transferir'),tileAction(Glyph.box,'Investir'),tileAction(Glyph.phone,'Recarga')])],
      gap(18),divider(),gap(16),
      if(spec.id=='next-iniciais')banner(const Rect.fromLTWH(40,1184,784,284),'Carteira digital') else banner(const Rect.fromLTWH(44,1422,816,114),'Você sempre ON'),
      dots(),gap(16),
    ])),
  ]);
  Widget nu()=>ListView(padding:EdgeInsets.zero,children:[
    Container(color:spec.accent,padding:EdgeInsets.fromLTRB(20*scale,8*scale,20*scale,22*scale),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[InkWell(onTap:edit,child:SceneAvatar(record:r,size:48*scale)),const Spacer(),icon(Icons.visibility_outlined,'Alternar saldo',hide,color:Colors.white),icon(Icons.help_outline,'Ajuda',()=>open('Ajuda'),color:Colors.white),icon(Icons.verified_user_outlined,'Segurança',()=>open('Segurança'),color:Colors.white)]),
      gap(26),if(spec.id=='nu-claro')InkWell(onTap:edit,child:text('Olá, ${r.text('name')}',size:21,color:Colors.white,weight:FontWeight.w500))
      else SizedBox(height:120*scale,child:ListView(scrollDirection:Axis.horizontal,children:[
        for(final rect in const [Rect.fromLTWH(49,174,325,235),Rect.fromLTWH(385,173,322,235),Rect.fromLTWH(715,173,149,235)])Padding(padding:const EdgeInsets.only(right:6),child:InkWell(onTap:()=>open('Destaques'),child:ClipRRect(borderRadius:BorderRadius.circular(18),child:ReferenceArt(spec.asset,rect,width:rect.width*120/235*scale,height:120*scale)))),
      ])),
    ])),
    Padding(padding:EdgeInsets.all(24*scale),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      InkWell(onTap:edit,child:Row(children:[text('Conta',size:21,weight:FontWeight.w600),const Spacer(),Icon(Icons.chevron_right,color:foreground)])),gap(6),amount(size:23),gap(32),
      SizedBox(height:100*scale+labelsHeight(const ['Área Pix','Pagar','Pegar\nemprestado','Transferir','Recarga de\ncelular'],86*scale,15,weight:FontWeight.w600),child:ListView(scrollDirection:Axis.horizontal,children:List.generate(5,(i){
        const labels=['Área Pix','Pagar','Pegar\nemprestado','Transferir','Recarga de\ncelular'];
        return SizedBox(width:86*scale,child:InkWell(onTap:()=>open(labels[i].replaceAll('\n',' ')),child:Column(children:[
          Container(width:76*scale,height:76*scale,decoration:BoxDecoration(shape:BoxShape.circle,color:spec.light?const Color(0xfff0f0f0):const Color(0xff222222)),child:Center(child:LineIcon([Glyph.pix,Glyph.barcode,Glyph.loan,Glyph.arrows,Glyph.phone][i],size:28*scale,color:foreground))),
          if(i==2)Container(color:spec.accent,padding:const EdgeInsets.symmetric(horizontal:3),child:text(money(r.cents('loan')).replaceAll(',00',''),size:12,color:Colors.white))else gap(15),gap(3),text(labels[i],size:15,weight:FontWeight.w600,align:TextAlign.center),
        ])));
      }))),
      Material(color:spec.light?const Color(0xfff0f0f0):const Color(0xff222222),borderRadius:BorderRadius.circular(18),child:ListTile(onTap:()=>open('Meus cartões'),leading:LineIcon(Glyph.card,color:foreground),title:text('Meus cartões',size:16,weight:FontWeight.w500),contentPadding:EdgeInsets.symmetric(horizontal:20*scale,vertical:10*scale))),
      gap(24),banner(spec.light?const Rect.fromLTWH(52,978,760,215):const Rect.fromLTWH(55,1148,760,202),'Convide amigos'),
    ])),divider(),Padding(padding:EdgeInsets.all(24*scale),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[text('Cartão de crédito',size:21,weight:FontWeight.w600),gap(22),text('Fatura atual',size:18),gap(7),amount(keyName:'invoice',size:23),gap(16)])),
  ]);
  Widget nuNav()=>SafeArea(top:false,child:Container(color:spec.background,child:Row(mainAxisAlignment:MainAxisAlignment.center,children:List.generate(3,(i)=>Container(margin:const EdgeInsets.symmetric(horizontal:6),decoration:BoxDecoration(color:tab==i?spec.accent.withValues(alpha:.25):Colors.transparent,shape:BoxShape.circle),child:IconButton(onPressed:(){setState(()=>tab=i);if(i!=0)open(i==1?'Investimentos':'Shopping');},icon:LineIcon([Glyph.arrows,Glyph.dollar,Glyph.bag][i],color:tab==i?spec.accent:Colors.grey),padding:const EdgeInsets.all(17)))))));
  Widget bradesco()=>ListView(padding:EdgeInsets.zero,children:[
    Container(decoration:const BoxDecoration(gradient:LinearGradient(colors:[Color(0xfff41462),Color(0xffe20b42),Color(0xffb8176b)],begin:Alignment.topCenter,end:Alignment.bottomCenter)),padding:EdgeInsets.fromLTRB(24*scale,8*scale,24*scale,48*scale),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[icon(Icons.menu,'Menu',()=>open('Menu'),color:Colors.white),SizedBox(width:26*scale),text('bradesco',size:25,color:Colors.white,weight:FontWeight.w600),const Spacer(),icon(Icons.notifications_none,'Notificações',()=>open('Notificações'),color:Colors.white)]),gap(16),
      Row(children:[const Icon(Icons.person_outline,color:Colors.white),const SizedBox(width:10),Expanded(child:InkWell(onTap:edit,child:text('Olá, ${r.text('name')}',size:19,color:Colors.white))),icon(Icons.logout,'Editar estudo',edit,color:Colors.white)]),const Divider(color:Colors.white38),gap(27),
      text('Meu saldo disponível',size:16,color:Colors.white),gap(6),Row(children:[Expanded(child:amount(size:21,color:Colors.white)),icon(Icons.visibility_off_outlined,'Alternar saldo',hide,color:Colors.white),TextButton(onPressed:()=>open('Extrato'),child:text('Ver extrato ›',size:16,color:Colors.white))]),
    ])),
    Padding(padding:EdgeInsets.symmetric(horizontal:24*scale),child:Column(children:[
      Transform.translate(offset:Offset(0,-26*scale),child:Material(color:Colors.white,elevation:3,shadowColor:Colors.black12,borderRadius:BorderRadius.circular(10),child:ListTile(onTap:()=>open('BIA'),title:Text.rich(TextSpan(children:[const TextSpan(text:'Fale com a ',style:TextStyle(color:Colors.grey,fontStyle:FontStyle.italic)),TextSpan(text:'BIA',style:TextStyle(color:spec.accent,fontWeight:FontWeight.w700,fontStyle:FontStyle.italic))]),style:TextStyle(fontSize:18*scale)),trailing:Icon(Icons.mic_none,color:spec.accent)))),
      Row(children:[Expanded(child:ListTile(contentPadding:EdgeInsets.zero,onTap:()=>open('Meus Bancos'),leading:Icon(Icons.account_balance,color:spec.accent),title:text('Meus Bancos',size:13))),Expanded(child:ListTile(contentPadding:EdgeInsets.zero,onTap:()=>open('Open Finance'),leading:Icon(Icons.donut_large,color:spec.accent),title:text('Open Finance',size:13)))]),gap(14),
      for(int row=0;row<3;row++)Padding(padding:EdgeInsets.only(bottom:13*scale),child:IntrinsicHeight(child:Row(crossAxisAlignment:CrossAxisAlignment.stretch,children:List.generate(2,(col){
        final i=row*2+col;const labels=['Transferências','Pagamentos','Cartões','Pix','Empréstimos/\nConsignado','Investimentos'];
        return Expanded(child:Padding(padding:EdgeInsets.only(right:col==0?12*scale:0),child:Material(color:Colors.white,borderRadius:BorderRadius.circular(13),elevation:3,shadowColor:Colors.black12,child:InkWell(onTap:()=>open(labels[i].replaceAll('\n',' ')),child:Padding(padding:EdgeInsets.symmetric(horizontal:13*scale,vertical:36*scale),child:Row(children:[LineIcon([Glyph.arrows,Glyph.barcode,Glyph.card,Glyph.pix,Glyph.loan,Glyph.dollar][i],color:const Color(0xffa20e42),size:25*scale),SizedBox(width:10*scale),Expanded(child:text(labels[i],size:14))]))))));
      })))),
      gap(6),banner(const Rect.fromLTWH(40,1197,614,98),'Seguro de vida'),dots(),
    ])),
    Container(padding:EdgeInsets.all(20*scale),decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(28))),child:Column(children:[TextButton(onPressed:()=>setState(()=>expanded=!expanded),child:text(expanded?'Menos serviços ⌄':'Mais serviços ⌃',color:const Color(0xffa20e42),size:17)),if(expanded)for(final name in ['Recarga','Débito automático','Seguros'])ListTile(title:text(name),onTap:()=>open(name))])),
  ]);
  Widget pagbank()=>ListView(padding:EdgeInsets.zero,children:[
    Padding(padding:EdgeInsets.symmetric(horizontal:15*scale,vertical:12*scale),child:Row(children:[art(const Rect.fromLTWH(40,24,247,78),width:135*scale),const Spacer(),icon(Icons.lock_outline,'Segurança',()=>open('Segurança'),color:Colors.white),icon(Icons.notifications_none,'Notificações',()=>open('Notificações'),color:Colors.white),icon(Icons.account_circle,'Editar perfil',edit,color:Colors.white)])),
    Padding(padding:EdgeInsets.symmetric(horizontal:13*scale),child:Column(children:[
      Container(padding:EdgeInsets.all(18*scale),decoration:BoxDecoration(color:const Color(0xff188b08),borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[text('Saldo',size:22,color:Colors.white,weight:FontWeight.w700),const Spacer(),icon(Icons.visibility_off_outlined,'Alternar saldo',hide,color:const Color(0xffffff9b))]),gap(14),Row(children:[Expanded(child:amount(size:30,color:Colors.white)),FilledButton(style:FilledButton.styleFrom(backgroundColor:const Color(0xff126900),foregroundColor:const Color(0xffffff9b)),onPressed:()=>open('Guardar'),child:text('Guardar',size:18,color:const Color(0xffffff9b),weight:FontWeight.w600))])])),gap(8),
      Container(width:double.infinity,padding:EdgeInsets.all(18*scale),decoration:BoxDecoration(color:const Color(0xff188b08),borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[text('Vendas a receber',size:19,color:Colors.white70),gap(6),amount(keyName:'receivable',size:23,color:Colors.white)])),gap(9),
      SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:const Color(0xff146b05),padding:EdgeInsets.all(18*scale)),onPressed:()=>open('Detalhes do saldo'),child:text('Ver detalhes do saldo',size:20,color:const Color(0xffffff9b)))),gap(14),
      banner(const Rect.fromLTWH(28,713,841,134),'Completar cadastro'),gap(14),
    ])),
    Container(clipBehavior:Clip.antiAlias,decoration:const BoxDecoration(color:Color(0xfff2f5f7),borderRadius:BorderRadius.vertical(top:Radius.circular(25))),child:Column(children:[
      Row(crossAxisAlignment:CrossAxisAlignment.start,children:List.generate(3,(i)=>Expanded(child:InkWell(onTap:()=>setState(()=>tab=i),child:Container(padding:EdgeInsets.symmetric(vertical:22*scale,horizontal:4*scale),color:tab==i?Colors.white:const Color(0xffe6f1f7),child:text(['Principais','Produtos\ne Serviços','Investimentos'][i],size:16,color:tab==i?const Color(0xff08758b):Colors.black,weight:FontWeight.w700,align:TextAlign.center)))))),
      for(int row=0;row<2;row++)IntrinsicHeight(child:Row(crossAxisAlignment:CrossAxisAlignment.stretch,children:List.generate(3,(col){
        final i=row*3+col;final labels=tab==0?['Pix/QR Code','Pagar\nContas','Cartões','Transferências','Recargas e Gift\nCards','Antecipar\nFGTS']:tab==1?['Maquininhas','Vendas','Cobranças','Conta PJ','Gift Cards','Seguros']:['CDB','Renda fixa','Fundos','Meu dinheiro','Objetivos','Simular'];
        return Expanded(child:InkWell(onTap:()=>open(labels[i].replaceAll('\n',' ')),child:Container(decoration:BoxDecoration(color:i==0||i==2?Colors.white:const Color(0xfff2f5f7),border:Border.all(color:const Color(0xffd8dcdf),width:.5)),padding:EdgeInsets.symmetric(horizontal:5*scale,vertical:22*scale),child:Column(children:[
          if(i==1||i==2||i==5)Container(padding:const EdgeInsets.symmetric(horizontal:5,vertical:2),decoration:BoxDecoration(color:const Color(0xfffae54c),borderRadius:BorderRadius.circular(12)),child:text(i==1?'EM ATÉ 12X':i==2?'1% DE CASHBACK':'MENORES TAXAS',size:10,color:Colors.black,weight:FontWeight.w700))else gap(18),
          LineIcon([Glyph.pix,Glyph.barcode,Glyph.card,Glyph.arrows,Glyph.phone,Glyph.loan][i],size:30*scale,color:i==0||i==2?const Color(0xff078399):Colors.grey),gap(24),text(labels[i],size:16,color:const Color(0xff555555),align:TextAlign.center),
        ]))));
      }))),
    ])),
  ]);
  Widget cooperative()=>ListView(padding:EdgeInsets.zero,children:[
    Container(height:38*scale,color:const Color(0xff368900)),
    Padding(padding:EdgeInsets.all(26*scale),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      banner(const Rect.fromLTWH(62,157,902,105),'Minha cooperativa'),gap(40),text('Saldo em conta corrente',size:18),gap(12),Row(children:[Expanded(child:amount(size:24)),icon(Icons.visibility_off_outlined,'Alternar saldo',hide,color:spec.accent)]),gap(20),TextButton(onPressed:()=>open('Detalhar saldo'),child:text('Detalhar saldo',size:17,color:spec.accent,weight:FontWeight.w600)),gap(30),
      SizedBox(height:115*scale+labelsHeight(const ['Extrato','Pagar Pix','Pagar\nboleto','Crédito','Recarga'],100*scale,18),child:ListView(scrollDirection:Axis.horizontal,children:List.generate(5,(i){const labels=['Extrato','Pagar Pix','Pagar\nboleto','Crédito','Recarga'];return SizedBox(width:100*scale,child:InkWell(onTap:()=>open(labels[i].replaceAll('\n',' ')),child:Column(children:[Container(width:84*scale,height:84*scale,margin:const EdgeInsets.all(3),decoration:const BoxDecoration(color:Colors.white,boxShadow:[BoxShadow(color:Colors.black12,blurRadius:8,offset:Offset(0,4))]),child:Center(child:LineIcon([Glyph.barcode,Glyph.pix,Glyph.dollar,Glyph.loan,Glyph.phone][i],color:spec.accent,size:31*scale))),gap(14),text(labels[i],size:18,align:TextAlign.center)])));}))),
      Material(color:Colors.white,elevation:3,shadowColor:Colors.black12,child:InkWell(onTap:()=>open('Cartões'),child:Padding(padding:EdgeInsets.all(26*scale),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[LineIcon(Glyph.card,color:spec.accent),const Spacer(),Icon(Icons.chevron_right,color:spec.accent)]),gap(14),text('Cartões',size:24,color:spec.accent),gap(20),text('Acesse a área de cartões, confira ofertas disponíveis e acompanhe seu cartão.',size:19,color:const Color(0xff606060))])))),gap(20),
    ])),
  ]);
  String usd(int cents){final br=money(cents).replaceFirst('R\$ ','');return '\$${br.replaceAll('.', '#').replaceAll(',', '.').replaceAll('#', ',')}';}
  Widget binance()=>ListView(padding:EdgeInsets.symmetric(horizontal:16*scale),children:[
    Row(children:[art(const Rect.fromLTWH(30,32,223,47),width:123*scale),const Spacer(),icon(Icons.search,'Search',()=>open('Search')),icon(Icons.qr_code_scanner,'Scan',()=>open('Scan')),icon(Icons.notifications_none,'Notifications',()=>open('Notifications'))]),gap(16),
    Row(children:[InkWell(onTap:edit,child:SceneAvatar(record:r,size:46*scale)),SizedBox(width:12*scale),Expanded(child:InkWell(onTap:edit,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[text(r.text('name'),size:19,weight:FontWeight.w600),gap(6),text('ID: ${r.text('accountId')}',size:13,color:Colors.grey)]))),text('✿ Verified',size:11,color:spec.accent,weight:FontWeight.w600)]),gap(26),
    Row(children:[text('Total Balance',size:13,color:Colors.grey),icon(Icons.visibility,'Hide balance',hide)]),
    Row(children:[Expanded(child:InkWell(onTap:edit,child:FittedBox(alignment:Alignment.centerLeft,fit:BoxFit.scaleDown,child:text(r.hidden?'\$••••••':usd(r.cents('balance')),size:31,weight:FontWeight.w600)))),const SizedBox(width:8),text('USD ⌄',size:13),const SizedBox(width:16),FilledButton(style:FilledButton.styleFrom(backgroundColor:spec.accent,foregroundColor:Colors.black,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(5))),onPressed:()=>open('Deposit'),child:const Text('Deposit'))]),gap(10),text(r.hidden?'≈ •••••• BTC':'≈ ${r.text('btc')} BTC',size:13,color:Colors.grey),gap(16),
    Row(crossAxisAlignment:CrossAxisAlignment.start,children:[tileAction(Glyph.arrows,'Deposit',fill:const Color(0xff181d25)),tileAction(Glyph.arrows,'Withdraw',fill:const Color(0xff181d25)),tileAction(Glyph.card,'Buy',fill:const Color(0xff181d25)),tileAction(Glyph.arrows,'Convert',fill:const Color(0xff181d25)),tileAction(Glyph.bag,'More',fill:const Color(0xff181d25))]),gap(20),
    banner(const Rect.fromLTWH(30,562,708,155),'Binance Earn'),gap(18),
    SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:List.generate(5,(i)=>TextButton(onPressed:()=>setState(()=>tab=i),child:text(['Favorites','Hot','Gainers','Losers','Portfolio'][i],size:14,color:(tab==0?i==4:tab==i)?Colors.white:Colors.grey))))),
    if(tab==0||tab==4)...[gap(16),text('Portfolio Value',size:13,color:Colors.grey),gap(10),InkWell(onTap:edit,child:text(r.hidden?'\$•••••• USD':'${usd(r.cents('balance'))} USD',size:25,weight:FontWeight.w600)),gap(7),text(r.hidden?'≈ •••••• BTC':'≈ ${r.text('btc')} BTC',size:13,color:Colors.grey),gap(14)]else Padding(padding:const EdgeInsets.symmetric(vertical:14),child:text('Market preview · reference values',size:13,color:Colors.grey)),
    for(int i=0;i<4;i++)Column(children:[ListTile(contentPadding:EdgeInsets.symmetric(vertical:8*scale),onTap:()=>open(['BTC','USDT','BNB','ETH'][i]),
      leading:ClipOval(child:art(Rect.fromLTWH(29,1019+i*111.0,60,60),width:33*scale)),
      title:text(['BTC','USDT','BNB','ETH'][i],size:15),subtitle:text(['Bitcoin','TetherUS','BNB','Ethereum'][i],size:13,color:Colors.grey),
      trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[text(r.hidden?'••••••':['0.03500000','900.00','0.25000000','0.10000000'][i],size:15),text(r.hidden?'••••••':['\$2,100.00','\$900.00','\$750.00','\$250.00'][i],size:13,color:Colors.grey)])),divider()]),gap(12),
  ]);
  Widget cryptoNav()=>SafeArea(top:false,child:Container(color:spec.background,child:Row(children:List.generate(5,(i)=>Expanded(child:InkWell(onTap:(){if(i!=0)open(['Home','Markets','Trade','Futures','Wallets'][i]);},child:Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon([Icons.home,Icons.bar_chart,Icons.currency_exchange,Icons.query_stats,Icons.account_balance_wallet][i],color:i==0?spec.accent:Colors.grey),const SizedBox(height:3),text(['Home','Markets','Trade','Futures','Wallets'][i],size:10,color:i==0?spec.accent:Colors.grey)]))))))));
}

class NextTransfer extends StatefulWidget {
  final SceneRecord record;
  const NextTransfer({super.key,required this.record});
  @override State<NextTransfer> createState()=>_NextTransferState();
}
class _NextTransferState extends State<NextTransfer> {
  late final amount=TextEditingController(text:money(widget.record.cents('amount')==0?80000:widget.record.cents('amount')).replaceFirst('R\$ ',''));
  late final recipient=TextEditingController(text:widget.record.text('recipient').isEmpty?'CLAUDIA MARIA DE OLIVEIRA DA FONSECA':widget.record.text('recipient'));
  bool hidden=false;
  String? error;
  @override void dispose(){amount.dispose();recipient.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Theme(data:ThemeData.dark().copyWith(scaffoldBackgroundColor:Colors.black,colorScheme:const ColorScheme.dark(primary:Color(0xff00ef57))),child:Scaffold(backgroundColor:Colors.black,
    appBar:AppBar(backgroundColor:Colors.black,foregroundColor:const Color(0xff00ef57),centerTitle:true,title:const Text('INSERIR VALOR',style:TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.w600)),actions:[IconButton(tooltip:'Sobre a demonstração',onPressed:()=>showDialog<void>(context:context,builder:(dialog)=>AlertDialog(title:const Text('Estudo de transferência'),content:const Text('Nenhum dinheiro é enviado. Nome, valor e saldo pertencem à demonstração.'),actions:[TextButton(onPressed:()=>Navigator.pop(dialog),child:const Text('Entendi'))])),icon:const Icon(Icons.info_outline))]),
    body:SafeArea(child:ListView(padding:const EdgeInsets.all(24),children:[
      const SizedBox(height:20),const Text('Qual o valor da transação para',textAlign:TextAlign.center,style:TextStyle(fontSize:27,height:1.2,color:Colors.white)),
      TextField(controller:recipient,textAlign:TextAlign.center,maxLines:null,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w600,color:Colors.white),decoration:const InputDecoration(border:InputBorder.none)),
      const Text('Verifique o nome antes de realizar a transferência',textAlign:TextAlign.center,style:TextStyle(fontSize:20,color:Colors.grey,fontWeight:FontWeight.w600)),
      const SizedBox(height:58),TextField(key:const Key('transfer-amount'),controller:amount,textAlign:TextAlign.center,keyboardType:const TextInputType.numberWithOptions(decimal:true),style:const TextStyle(fontSize:40,fontWeight:FontWeight.w700,color:Colors.white),decoration:InputDecoration(prefixText:'R\$ ',errorText:error)),
      const SizedBox(height:50),Row(children:[const Expanded(child:Text('Saldo conta\n-poupança',style:TextStyle(fontSize:20,fontWeight:FontWeight.w600,color:Colors.white))),Flexible(child:FittedBox(child:Text(hidden?'R\$ ••••••':money(widget.record.cents('balance')),style:const TextStyle(fontSize:20,color:Colors.white,fontWeight:FontWeight.w600)))),IconButton(tooltip:'Alternar saldo',onPressed:()=>setState(()=>hidden=!hidden),icon:const Icon(Icons.visibility_off_outlined,color:Colors.white))]),
      const SizedBox(height:60),FilledButton(key:const Key('transfer-next'),style:FilledButton.styleFrom(backgroundColor:const Color(0xff00ef57),foregroundColor:Colors.black,padding:const EdgeInsets.all(24),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(8))),onPressed:()async{
        final cents=parseMoney(amount.text);
        if(cents==null||cents<=0||recipient.text.trim().isEmpty){setState(()=>error='Informe nome e valor válidos.');return;}
        if(cents>widget.record.cents('balance')){setState(()=>error='O valor supera o saldo demonstrativo.');return;}
        setState(()=>error=null);
        await showDialog<void>(context:context,builder:(dialog)=>AlertDialog(title:const Text('Revisar demonstração'),content:Text('${recipient.text.trim()}\n${money(cents)}\n\nNenhuma transferência será realizada.'),actions:[TextButton(onPressed:()=>Navigator.pop(dialog),child:const Text('Voltar')),FilledButton(onPressed:(){Navigator.pop(dialog);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Demonstração concluída. Nenhum valor movimentado.')));},child:const Text('Concluir estudo'))]));
      },child:const Text('AVANÇAR',style:TextStyle(fontSize:17,fontWeight:FontWeight.w700))),
    ])),
  ));
}

class DemoPanel extends StatelessWidget {
  final SceneRecord record;
  final String title;
  const DemoPanel({super.key,required this.record,required this.title});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(title)),body:ListView(padding:const EdgeInsets.all(24),children:[
    Icon(title.toLowerCase().contains('cart')?Icons.credit_card:Icons.touch_app_outlined,size:50,color:record.spec.accent),const SizedBox(height:24),Text(title,style:const TextStyle(fontSize:30,fontWeight:FontWeight.w600)),const SizedBox(height:16),
    if(title.contains('Extrato')||title.contains('saldo'))...[const Text('Saldo demonstrativo'),Text(record.hidden?'••••••':money(record.cents('balance')),style:const TextStyle(fontSize:28)),const SizedBox(height:18),const Text('Nenhuma movimentação. Os valores foram definidos para este estudo.')]
    else if(title=='Ajuda'||title=='Menu'||title=='More')...[const Text('Explore os atalhos, edite o perfil ou volte ao catálogo para comparar variantes.'),ListTile(leading:const Icon(Icons.tune),title:const Text('Personalizar este estudo'),onTap:()=>editScene(context,record)),ListTile(leading:const Icon(Icons.grid_view),title:const Text('Voltar ao catálogo'),onTap:()=>Navigator.popUntil(context,(route)=>route.isFirst))]
    else ...[const Text('Esta tela é uma extensão demonstrativa. O print fornecido mostra a tela inicial, não este fluxo.'),const SizedBox(height:24),
      ListTile(title:const Text('Revisar dados do estudo'),trailing:const Icon(Icons.chevron_right),onTap:()=>editScene(context,record)),
      if(record.spec.family=='next')FilledButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>NextTransfer(record:record))),child:const Text('Abrir estudo de transferência')),
      const SizedBox(height:18),const Text('Sem conexão com a instituição, movimentação de dinheiro ou geração de comprovantes.',style:TextStyle(color:Colors.grey)),
    ],
  ]));
}
