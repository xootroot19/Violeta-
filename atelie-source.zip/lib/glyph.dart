import 'dart:math' as math;
import 'package:flutter/material.dart';

enum Glyph { pix, barcode, loan, box, phone, card, eye, help, shield, arrows, dollar, bag, chevron, close, back, edit, check }
class LineIcon extends StatelessWidget {
  final Glyph glyph;
  final double size;
  final Color color;
  const LineIcon(this.glyph, {super.key, this.size = 26, this.color = const Color(0xffe9e9e9)});
  @override
  Widget build(BuildContext context) => SizedBox.square(dimension: size, child: CustomPaint(painter: _GlyphPainter(glyph, color)));
}
class _GlyphPainter extends CustomPainter {
  final Glyph glyph;
  final Color color;
  _GlyphPainter(this.glyph, this.color);
  @override
  void paint(Canvas c, Size s) {
    c.scale(s.width / 32, s.height / 32);
    final p = Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 2.1..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round;
    void line(List<Offset> points) { final path = Path()..moveTo(points[0].dx, points[0].dy); for(final a in points.skip(1)) { path.lineTo(a.dx,a.dy); } c.drawPath(path,p); }
    void text(String value, double x, double y, double size) {
      final t = TextPainter(text: TextSpan(text: value, style: TextStyle(color: color,fontSize: size,fontWeight: FontWeight.w400)),textDirection: TextDirection.ltr)..layout(); t.paint(c,Offset(x,y));
    }
    switch(glyph) {
      case Glyph.pix:
        for (int i=0;i<4;i++) {
          c.save(); c.translate(16,16); c.rotate(math.pi/2*i);
          final path = Path()..moveTo(-6,-9)..lineTo(-1.9,-13.1)..quadraticBezierTo(0,-15,1.9,-13.1)..lineTo(6,-9)..lineTo(0,-3)..close(); c.drawPath(path,p); c.restore();
        }
      case Glyph.barcode:
        final f = Paint()..color=color;
        for(final r in [const Rect.fromLTWH(4,9,2,14),const Rect.fromLTWH(9,9,3,14),const Rect.fromLTWH(15,9,2,14),const Rect.fromLTWH(20,9,4,14),const Rect.fromLTWH(27,9,1,14)]) { c.drawRect(r,f); }
      case Glyph.loan:
        c.drawCircle(const Offset(16,11),8,p); text('\$',11,0,18);
        c.drawPath(Path()..moveTo(5,27)..lineTo(5,21)..quadraticBezierTo(6,17,10,17)..lineTo(18,17)..quadraticBezierTo(22,18,18,21)..lineTo(12,21),p);
        c.drawPath(Path()..moveTo(5,27)..lineTo(20,27)..lineTo(28,19)..quadraticBezierTo(30,15,26,15)..lineTo(20,20),p);
      case Glyph.box:
        c.drawArc(const Rect.fromLTWH(8,3,17,19),math.pi,math.pi*1.25,false,p); text('\$',12,0,18);
        c.drawRect(const Rect.fromLTWH(5,17,24,13),p); line([const Offset(3,17),const Offset(30,17)]);
      case Glyph.phone:
      case Glyph.card:
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(7,2,18,28),const Radius.circular(4)),p);
        if(glyph==Glyph.card) { line([const Offset(18,8),const Offset(18,11)]); } else { line([const Offset(14,25),const Offset(18,25)]); }
      case Glyph.eye:
        c.drawPath(Path()..moveTo(2,18)..quadraticBezierTo(15,-2,30,18),p); c.drawCircle(const Offset(16,17),4.2,p);
      case Glyph.help:
        c.drawCircle(const Offset(16,16),13,p); text('?',10,0,25);
      case Glyph.shield:
        line([const Offset(26,8),const Offset(16,3),const Offset(5,8),const Offset(5,19),const Offset(8,25),const Offset(16,30),const Offset(24,24),const Offset(27,18)]);
        line([const Offset(12,14),const Offset(16,18),const Offset(27,7)]);
      case Glyph.arrows:
        line([const Offset(9,22),const Offset(9,3),const Offset(3,9)]); line([const Offset(9,3),const Offset(15,9)]);
        line([const Offset(24,10),const Offset(24,29),const Offset(18,23)]); line([const Offset(24,29),const Offset(30,23)]);
      case Glyph.dollar:
        c.drawPath(Path()..moveTo(25,8)..cubicTo(10,-1,3,13,15,15)..cubicTo(32,18,23,32,7,25),p); line([const Offset(16,1),const Offset(16,30)]);
      case Glyph.bag:
        c.drawPath(Path()..moveTo(6,11)..lineTo(4,27)..quadraticBezierTo(4,30,8,30)..lineTo(26,30)..quadraticBezierTo(29,30,28,26)..lineTo(26,11),p);
        c.drawArc(const Rect.fromLTWH(12,2,10,15),math.pi,math.pi,false,p);
      case Glyph.chevron:
        line([const Offset(12,9),const Offset(19,16),const Offset(12,23)]);
      case Glyph.back:
        line([const Offset(19,6),const Offset(9,16),const Offset(19,26)]);
      case Glyph.close:
        line([const Offset(7,7),const Offset(25,25)]); line([const Offset(25,7),const Offset(7,25)]);
      case Glyph.edit:
        line([const Offset(6,21),const Offset(22,5),const Offset(27,10),const Offset(11,26),const Offset(5,27),const Offset(6,21)]);
      case Glyph.check:
        line([const Offset(5,16),const Offset(12,23),const Offset(27,8)]);
    }
  }
  @override
  bool shouldRepaint(covariant _GlyphPainter old) => old.glyph != glyph || old.color != color;
}
