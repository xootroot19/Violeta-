import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'glyph.dart';
import 'model.dart';
import 'bb.dart';
import 'hub.dart';

const purple = Color(0xff69238f);
const tile = Color(0xff252525);
const ink = Color(0xffeeeeee);
ui.Image? referenceImage;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(statusBarColor: purple, statusBarIconBrightness: Brightness.light, systemNavigationBarColor: Colors.black, systemNavigationBarIconBrightness: Brightness.light));
  final prefs = await SharedPreferences.getInstance();
  const family = String.fromEnvironment('STUDY_FAMILY', defaultValue: 'all');
  if (family == 'all' || family == 'nubank') {
    final bytes = await rootBundle.load('assets/reference.jpg');
    final codec = await ui.instantiateImageCodec(bytes.buffer.asUint8List());
    referenceImage = (await codec.getNextFrame()).image;
    codec.dispose();
  }
  if (family == 'all' || family == 'bb') {
    final bbBytes = await rootBundle.load('assets/bb-reference.jpg');
    final bbCodec = await ui.instantiateImageCodec(bbBytes.buffer.asUint8List());
    bbReference = (await bbCodec.getNextFrame()).image;
    bbCodec.dispose();
  }
  final profile = Profile(prefs)..restoreSnapshot();
  runApp(StudyApp(profile: profile));
}

class StudyApp extends StatelessWidget {
  final Profile profile;
  final bool showSplash;
  const StudyApp({super.key, required this.profile, this.showSplash = true});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Ateliê — Estudos de interfaces', debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: Colors.black, primaryColor: purple,
      colorScheme: const ColorScheme.dark(primary: Color(0xffc78beb), surface: tile),
      fontFamily: 'Roboto', useMaterial3: true,
      textTheme: const TextTheme(bodyMedium: TextStyle(color: ink, fontSize: 16)),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: tile,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xffc78beb)))),
      bottomSheetTheme: const BottomSheetThemeData(backgroundColor: Color(0xff141414), surfaceTintColor: Colors.transparent),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.black, foregroundColor: ink, surfaceTintColor: Colors.transparent)),
    home: showSplash ? StudySplash(profile: profile) : Home(profile: profile));
}
class StudySplash extends StatelessWidget {
  final Profile profile;
  const StudySplash({super.key, required this.profile});
  @override Widget build(BuildContext context) => StudyNotice(profile: profile);
}

class Avatar extends StatelessWidget {
  final Uint8List? photo;
  final double size;
  const Avatar({super.key,this.photo,this.size = 48});
  @override
  Widget build(BuildContext context) => ClipOval(child: SizedBox.square(dimension: size,child: photo != null
    ? Image.memory(photo!,fit: BoxFit.cover,errorBuilder: (_,__,___) => const Icon(Icons.person))
    : CustomPaint(painter: _AvatarPainter())));
}
class _AvatarPainter extends CustomPainter {
  @override
  void paint(Canvas c, Size s) {
    if(referenceImage == null) { c.drawCircle(s.center(Offset.zero),s.width/2,Paint()..color=purple); return; }
    c.drawImageRect(referenceImage!,const Rect.fromLTWH(33,67,102,102),Offset.zero & s,Paint()..filterQuality=FilterQuality.high);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class Home extends StatefulWidget {
  final Profile profile;
  const Home({super.key,required this.profile});
  @override
  State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  int tab = 0;
  int banner = 0;
  final pageController = PageController();
  Profile get p => widget.profile;
  @override
  void dispose() { pageController.dispose(); super.dispose(); }
  void edit() => Navigator.of(context).push(MaterialPageRoute(builder: (_) => EditProfile(profile: p)));
  void detail(String title) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => DetailPage(title: title,profile: p)));
  Widget button(Glyph glyph, String label, VoidCallback action,{double size=24}) => IconButton(tooltip: label,onPressed: () { HapticFeedback.selectionClick(); action(); },icon: LineIcon(glyph,size: size));
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: p,builder: (context,_) => Scaffold(
    body: Stack(children: [
      Positioned.fill(child: tab == 0 ? account() : otherTab()),
      Positioned(bottom: MediaQuery.paddingOf(context).bottom+12,left: 0,right: 0,child: Center(child: Container(
        width: 194,height: 58,decoration: BoxDecoration(color: const Color(0xff080808),borderRadius: BorderRadius.circular(40),boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .65),blurRadius: 22,spreadRadius: 6)]),
        child: Row(children: List.generate(3,(i) => Expanded(child: Semantics(selected: tab == i,label: ['Conta','Investimentos','Shopping'][i],button: true,
          child: Tooltip(message: ['Conta','Investimentos','Shopping'][i],child: GestureDetector(onTap: () { HapticFeedback.selectionClick(); setState(() => tab=i); },
            child: AnimatedContainer(duration: const Duration(milliseconds: 220),margin: const EdgeInsets.all(2),decoration: BoxDecoration(color: tab==i ? const Color(0xff410e64) : Colors.transparent,borderRadius: BorderRadius.circular(40)),
              child: Center(child: LineIcon([Glyph.arrows,Glyph.dollar,Glyph.bag][i],color: tab==i ? const Color(0xffca8eec) : const Color(0xffbdbdbd),size: 25)))))))))))),
    ])));
  Widget account() => RefreshIndicator(color: const Color(0xffc78beb),onRefresh: () async { await Future<void>.delayed(const Duration(milliseconds: 450)); },child: CustomScrollView(physics: const AlwaysScrollableScrollPhysics(),slivers: [
    SliverToBoxAdapter(child: Container(color: purple,padding: EdgeInsets.fromLTRB(16,MediaQuery.paddingOf(context).top+8,16,22),child: Column(crossAxisAlignment: CrossAxisAlignment.start,children:[
      Row(children:[
        Semantics(label: 'Editar nome, foto e saldo',button: true,child: GestureDetector(onTap: edit,child: Avatar(photo:p.photo))),
        const Spacer(),
        button(Glyph.eye,p.hidden ? 'Mostrar valores' : 'Ocultar valores',() async { try { await p.toggleHidden(); } catch (_) { if(mounted) showMessage(context,'Não foi possível salvar a preferência.'); } }),
        button(Glyph.help,'Ajuda',() => detail('Ajuda')),
        button(Glyph.shield,'Segurança',() => detail('Segurança')),
      ]),
      const SizedBox(height: 30),
      Padding(padding: const EdgeInsets.only(left: 8),child: InkWell(onTap: edit,child: Padding(padding: const EdgeInsets.symmetric(vertical: 4),child: Text('Olá, ${p.name}',style: const TextStyle(fontSize: 20,fontWeight: FontWeight.w500))))),
    ]))),
    SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(24,27,24,0),child: InkWell(onTap: () => detail('Saldo em conta'),onLongPress: edit,child: Column(crossAxisAlignment: CrossAxisAlignment.start,children:[
      const Row(children:[Text('Saldo em conta',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500)),Spacer(),LineIcon(Glyph.chevron,size: 25)]),
      const SizedBox(height: 5),Text(p.hidden ? 'R\$ ••••••' : money(p.balance),style: const TextStyle(fontSize: 22,fontWeight: FontWeight.w500)),
    ])))),
    SliverToBoxAdapter(child: ShortcutRail(onSelected: detail)),
    SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(24,21,24,0),child: Material(color:tile,borderRadius:BorderRadius.circular(17),child: InkWell(borderRadius:BorderRadius.circular(17),onTap: () => detail('Meus cartões'),child: const Padding(padding:EdgeInsets.symmetric(horizontal:18,vertical:17),child: Row(children:[LineIcon(Glyph.card,size:23),SizedBox(width:20),Text('Meus cartões',style:TextStyle(fontSize:16,fontWeight:FontWeight.w500))])))))),
    SliverToBoxAdapter(child: Padding(padding:const EdgeInsets.fromLTRB(24,24,24,23),child: Container(height:MediaQuery.sizeOf(context).width < 370 ? 120 : 96,clipBehavior:Clip.antiAlias,decoration:BoxDecoration(color:const Color(0xff24205d),borderRadius:BorderRadius.circular(16)),child: Stack(children:[
      PageView(controller:pageController,onPageChanged:(v)=>setState(()=>banner=v),children:List.generate(3,(i)=>InkWell(onTap:()=>detail(i==0?'Caixinhas':i==1?'Meus cartões':'Segurança'),child:Padding(padding:const EdgeInsets.fromLTRB(16,15,16,25),child:Row(children:[
        Expanded(child:Text.rich(TextSpan(children:[TextSpan(text:['Facilite seus planos futuros: ','Seu cartão, do seu jeito: ','Mais tranquilidade: '][i],style:const TextStyle(fontWeight:FontWeight.w500)),TextSpan(text:['guarde dinheiro nas Caixinhas','gerencie tudo em um só lugar','conheça os recursos de segurança'][i])]),style:const TextStyle(fontSize:15,height:1.45))),
        const SizedBox(width:12),Container(width:56,height:56,decoration:const BoxDecoration(color:Color(0xff070329),shape:BoxShape.circle),child: Center(child:i==0 ? const GiftArt() : LineIcon(i==1?Glyph.card:Glyph.shield,size:28,color:const Color(0xffd7aaff)))),
      ]))))),
      Positioned(bottom:8,left:0,right:0,child:Row(mainAxisAlignment:MainAxisAlignment.center,children:List.generate(3,(i)=>Semantics(label:'Destaque ${i+1}',button:true,selected:i==banner,child:GestureDetector(onTap:()=>pageController.animateToPage(i,duration:const Duration(milliseconds:250),curve:Curves.easeOut),child:Padding(padding:const EdgeInsets.symmetric(horizontal:4,vertical:1),child:Container(width:6,height:6,decoration:BoxDecoration(color:i==banner?ink:const Color(0xff515155),shape:BoxShape.circle)))))))),
    ])))),
    SliverToBoxAdapter(child:Container(height:2,color:tile)),
    SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(24,25,24,0),child:InkWell(onTap:()=>detail('Cartão de crédito'),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Row(children:[Expanded(child:Text('Cartão de crédito',style:TextStyle(fontSize:20,fontWeight:FontWeight.w500))),LineIcon(Glyph.chevron)]),
      const SizedBox(height:16),const Text('Fatura atual',style:TextStyle(fontSize:16,color:Color(0xffbebebe))),const SizedBox(height:6),Text(p.hidden?'R\$ ••••••':'R\$ 304,87',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w500)),
      const SizedBox(height:12),Text(p.hidden?'Limite disponível ••••••':'Limite disponível de R\$ 4.695,13',style:const TextStyle(color:Color(0xffb4b4b4))),
    ])))),
    const SliverToBoxAdapter(child:SizedBox(height:24)),
    SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.symmetric(horizontal:24),child:OutlinedButton(onPressed:()=>detail('Cartão de crédito'),child:const Text('Acompanhar fatura')))),
    SliverToBoxAdapter(child:SizedBox(height:110+MediaQuery.paddingOf(context).bottom)),
  ]));
  Widget otherTab() => SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(24,24,24,110),children:[
    Row(children:[GestureDetector(onTap:edit,child:Avatar(photo:p.photo)),const Spacer(),button(Glyph.help,'Ajuda',()=>detail('Ajuda'))]),
    const SizedBox(height:35),Text(tab==1?'Seu dinheiro,\nnovas possibilidades.':'Uma seleção\npara você.',style:const TextStyle(fontSize:34,fontWeight:FontWeight.w500,height:1.1,letterSpacing:-1)),
    const SizedBox(height:12),Text(tab==1?'Organize seus planos e acompanhe cada conquista.':'Explore os benefícios do seu dia a dia.',style:const TextStyle(color:Color(0xffb4b4b4),fontSize:16,height:1.5)),
    const SizedBox(height:30),
    for(final label in tab==1?['Caixinhas','Caixinha Turbo','Saldo em conta']:['Meus cartões','Recarga de celular','Doações']) Padding(padding:const EdgeInsets.only(bottom:14),child:Material(color:tile,borderRadius:BorderRadius.circular(20),child:ListTile(contentPadding:const EdgeInsets.all(20),leading:LineIcon(tab==1?Glyph.box:Glyph.bag),title:Text(label),subtitle:Text(tab==1?'Seus objetivos começam aqui':'Conheça as possibilidades'),trailing:const LineIcon(Glyph.chevron),onTap:()=>detail(label)))),
  ]));
}
// Measure labels with the same font, width and text scale used to render them.
// This preserves the reference spacing while allowing wrapped or enlarged text.
class ShortcutRail extends StatelessWidget {
  final ValueChanged<String> onSelected;
  const ShortcutRail({super.key, required this.onSelected});

  static const titles = [
    'Área Pix e\nTransferir', 'Pagar', 'Pegar\nemprestado',
    'Caixinha\nTurbo', 'Recarga de\ncelular', 'Depositar', 'Doações',
  ];
  static const glyphs = [
    Glyph.pix, Glyph.barcode, Glyph.loan, Glyph.box,
    Glyph.phone, Glyph.arrows, Glyph.bag,
  ];

  @override
  Widget build(BuildContext context) {
    const itemWidth = 76.0;
    const iconHeight = 80.0;
    final style = DefaultTextStyle.of(context).style.merge(
      const TextStyle(fontSize: 15, height: 1.2, fontWeight: FontWeight.w500),
    );
    final scaler = MediaQuery.textScalerOf(context);
    final direction = Directionality.of(context);
    final locale = Localizations.maybeLocaleOf(context);
    double labelHeight = 0;
    for (final label in titles) {
      final painter = TextPainter(
        text: TextSpan(text: label, style: style),
        textDirection: direction,
        textScaler: scaler,
        locale: locale,
        textAlign: TextAlign.center,
      )..layout(maxWidth: itemWidth);
      if (painter.height > labelHeight) labelHeight = painter.height;
      painter.dispose();
    }
    final neededHeight = iconHeight + labelHeight.ceilToDouble() + 4;
    final railHeight = neededHeight > 123 ? neededHeight : 123.0;
    return Padding(
      padding: const EdgeInsets.only(top: 38),
      child: SizedBox(
        height: railHeight,
        child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          scrollDirection: Axis.horizontal,
          itemCount: titles.length,
          separatorBuilder: (_, __) => const SizedBox(width: 7),
          itemBuilder: (context, i) => SizedBox(
            width: itemWidth,
            child: InkWell(
              borderRadius: BorderRadius.circular(38),
              onTap: () => onSelected(titles[i].replaceAll('\n', ' ')),
              child: Column(
                children: [
                  SizedBox(
                    height: iconHeight,
                    child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Container(
                          width: 72, height: 72,
                          decoration: const BoxDecoration(shape: BoxShape.circle, color: tile),
                          child: Center(child: LineIcon(glyphs[i], size: 26)),
                        ),
                        if (i == 2 || i == 3)
                          Positioned(
                            bottom: 8,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                              decoration: BoxDecoration(color: purple, borderRadius: BorderRadius.circular(3)),
                              child: Text(i == 2 ? 'FGTS' : '115% CDI', style: const TextStyle(fontSize: 13)),
                            ),
                          ),
                      ],
                    ),
                  ),
                  Text(titles[i], style: style, textScaler: scaler,
                    textDirection: direction, locale: locale, textAlign: TextAlign.center),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GiftArt extends StatelessWidget {
  const GiftArt({super.key});
  @override
  Widget build(BuildContext context)=>SizedBox.square(dimension:32,child:CustomPaint(painter:_GiftPainter()));
}
class _GiftPainter extends CustomPainter {
  @override
  void paint(Canvas c,Size s){
    c.scale(s.width/32); final p=Paint();
    p.shader=const LinearGradient(colors:[Color(0xfff3e4ff),Color(0xffbe6ff1)],begin:Alignment.topLeft,end:Alignment.bottomRight).createShader(const Rect.fromLTWH(3,10,27,20));
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(4,11,24,19),const Radius.circular(1)),p);
    p.shader=null; p.color=const Color(0xffe5ccf9);c.drawPath(Path()..moveTo(4,14)..lineTo(0,7)..lineTo(12,7)..lineTo(16,14)..close(),p);
    p.color=const Color(0xffb762ed);c.drawPath(Path()..moveTo(16,14)..lineTo(21,7)..lineTo(32,7)..lineTo(28,14)..close(),p);
    p.color=const Color(0xfff6eaff);c.drawRect(const Rect.fromLTWH(14,14,3,16),p);
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>false;
}
void showMessage(BuildContext context,String text)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text),behavior:SnackBarBehavior.floating));

class EditProfile extends StatefulWidget {
  final Profile profile;
  const EditProfile({super.key,required this.profile});
  @override State<EditProfile> createState()=>_EditProfileState();
}
class _EditProfileState extends State<EditProfile> {
  final form=GlobalKey<FormState>();
  late final TextEditingController name;
  late final TextEditingController balance;
  Uint8List? photo;
  bool saving=false;
  bool picking=false;
  @override void initState(){super.initState();name=TextEditingController(text:widget.profile.name);balance=TextEditingController(text:money(widget.profile.balance).replaceFirst('R\$ ',''));photo=widget.profile.photo;}
  @override void dispose(){name.dispose();balance.dispose();super.dispose();}
  Future<void> pickPhoto()async{
    setState(()=>picking=true);
    try{
      final selected=await ImagePicker().pickImage(source:ImageSource.gallery,maxWidth:800,maxHeight:800,imageQuality:85);
      if(selected!=null){
        final bytes=await selected.readAsBytes();
        if(bytes.length>5*1024*1024) throw Exception('Imagem muito grande');
        final codec=await ui.instantiateImageCodec(bytes); final frame=await codec.getNextFrame(); frame.image.dispose();codec.dispose();
        if(mounted) setState(()=>photo=bytes);
      }
    }catch(_){if(mounted)showMessage(context,'Não foi possível abrir a foto. Escolha outra imagem.');}
    finally{if(mounted)setState(()=>picking=false);}
  }
  Future<void> save()async{
    if(!form.currentState!.validate())return;
    setState(()=>saving=true);
    try{
      await widget.profile.update(name.text.trim(),parseMoney(balance.text)!,photo);
      if(mounted){Navigator.pop(context);showMessage(context,'Perfil atualizado.');}
    }catch(_){if(mounted){setState(()=>saving=false);showMessage(context,'Não foi possível salvar. Tente novamente.');}}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Seu perfil'),actions:[IconButton(tooltip:'Hub de estudos',onPressed:()=>Navigator.of(context).popUntil((route)=>route.isFirst),icon:const Icon(Icons.grid_view))],leading:IconButton(tooltip:'Voltar',onPressed:saving?null:()=>Navigator.pop(context),icon:const LineIcon(Glyph.back))),body:SafeArea(child:Form(key:form,child:ListView(padding:const EdgeInsets.fromLTRB(24,24,24,32),children:[
    Center(child:Stack(children:[Avatar(photo:photo,size:104),Positioned(bottom:0,right:0,child:Container(decoration:const BoxDecoration(shape:BoxShape.circle,color:purple),child:IconButton(tooltip:'Alterar foto',onPressed:picking||saving?null:pickPhoto,icon:const LineIcon(Glyph.edit,size:20))))])),
    const SizedBox(height:12),Center(child:TextButton(onPressed:picking||saving?null:pickPhoto,child:Text(picking?'Abrindo galeria…':'Escolher foto'))),
    if(photo!=null)Center(child:TextButton(onPressed:saving?null:()=>setState(()=>photo=null),child:const Text('Restaurar foto original'))),
    const SizedBox(height:24),const Text('DO SEU JEITO',style:TextStyle(fontSize:12,letterSpacing:1.8,color:Color(0xffbb85d6))),
    const SizedBox(height:12),const Text('Personalize sua tela.',style:TextStyle(fontSize:28,fontWeight:FontWeight.w500,letterSpacing:-.7)),const SizedBox(height:10),
    const Text('Seu nome, sua foto e o saldo que aparece na demonstração.',style:TextStyle(fontSize:15,color:Color(0xffaaaaaa),height:1.5)),
    const SizedBox(height:28),TextFormField(key:const Key('name-field'),controller:name,enabled:!saving,maxLength:28,textCapitalization:TextCapitalization.words,decoration:const InputDecoration(labelText:'Nome',hintText:'Como você quer ser chamado?'),validator:(v)=>v==null||v.trim().isEmpty?'Digite seu nome.':null),
    const SizedBox(height:16),TextFormField(key:const Key('balance-field'),controller:balance,enabled:!saving,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Saldo demonstrativo',prefixText:'R\$ ',helperText:'Exemplo: 588.444,49'),validator:(v)=>parseMoney(v??'')==null?'Informe um valor válido em reais.':null),
    const SizedBox(height:28),SizedBox(height:54,child:FilledButton(key:const Key('save-profile'),style:FilledButton.styleFrom(backgroundColor:purple,foregroundColor:Colors.white),onPressed:saving||picking?null:save,child:saving?const SizedBox.square(dimension:20,child:CircularProgressIndicator(strokeWidth:2)):const Text('Salvar alterações',style:TextStyle(fontSize:16,fontWeight:FontWeight.w600)))),
  ]))));
}

class DetailPage extends StatefulWidget {
  final String title;
  final Profile profile;
  const DetailPage({super.key,required this.title,required this.profile});
  @override State<DetailPage> createState()=>_DetailPageState();
}
class _DetailPageState extends State<DetailPage>{
  bool locked=false;
  int goal=0;
  String selectedGoal='Minha viagem';
  final input=TextEditingController();
  final form=GlobalKey<FormState>();
  @override void dispose(){input.dispose();super.dispose();}
  Widget title(String text)=>Padding(padding:const EdgeInsets.only(bottom:16),child:Text(text,style:const TextStyle(fontSize:30,fontWeight:FontWeight.w500,letterSpacing:-.8,height:1.16)));
  Widget note(String text)=>Padding(padding:const EdgeInsets.only(bottom:24),child:Text(text,style:const TextStyle(color:Color(0xffb6b6b6),fontSize:16,height:1.55)));
  Widget action(String label,VoidCallback onTap)=>Padding(padding:const EdgeInsets.only(top:16),child:SizedBox(width:double.infinity,height:52,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:purple,foregroundColor:Colors.white),onPressed:onTap,child:Text(label,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w600)))));
  Widget row(String label,String value)=>Padding(padding:const EdgeInsets.symmetric(vertical:14),child:Row(children:[Expanded(child:Text(label,style:const TextStyle(color:Color(0xffb6b6b6)))),const SizedBox(width:12),Flexible(child:Text(value,textAlign:TextAlign.end,style:const TextStyle(fontWeight:FontWeight.w500,fontSize:17)))]));
  Future<void> result(String text)async{
    await showModalBottomSheet<void>(context:context,showDragHandle:true,isScrollControlled:true,builder:(sheet)=>SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(24,16,24,32),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      Container(padding:const EdgeInsets.all(16),decoration:const BoxDecoration(color:purple,shape:BoxShape.circle),child:const LineIcon(Glyph.check,size:28)),const SizedBox(height:24),
      const Text('Demonstração concluída',style:TextStyle(fontSize:25,fontWeight:FontWeight.w500)),const SizedBox(height:12),Text(text,style:const TextStyle(fontSize:16,height:1.5,color:Color(0xffbebebe))),const SizedBox(height:16),
      action('Entendi',()=>Navigator.pop(sheet)),
    ]))));
  }
  @override Widget build(BuildContext context)=>ListenableBuilder(listenable:widget.profile,builder:(context,_)=>Scaffold(appBar:AppBar(leading:IconButton(tooltip:'Voltar',onPressed:()=>Navigator.pop(context),icon:const LineIcon(Glyph.back)),actions:[IconButton(tooltip:'Fechar',onPressed:()=>Navigator.pop(context),icon:const LineIcon(Glyph.close))]),body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(24,12,24,32),children:content()))));
  List<Widget> content(){
    final t=widget.title;
    final p=widget.profile;
    if(t=='Saldo em conta')return[
      title('Seu dinheiro'),note('Saldo disponível'),Text(p.hidden?'R\$ ••••••':money(p.balance),style:const TextStyle(fontSize:36,fontWeight:FontWeight.w500)),const SizedBox(height:32),
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:tile,borderRadius:BorderRadius.circular(20)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[LineIcon(Glyph.arrows),SizedBox(height:16),Text('Tudo em um só lugar',style:TextStyle(fontSize:21)),SizedBox(height:8),Text('O saldo desta conta é editável para explorar diferentes composições da interface.',style:TextStyle(color:Color(0xffbbbbbb),height:1.5))])),
      action('Editar saldo',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>EditProfile(profile:p)))),
      const SizedBox(height:32),title('Movimentações'),note('Nenhuma movimentação. Esta é uma conta demonstrativa.'),
    ];
    if(t=='Meus cartões'||t=='Cartão de crédito')return[
      title(t),note('Controle seus cartões e acompanhe a fatura.'),
      Container(height:204,padding:const EdgeInsets.all(24),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xff883cb0),Color(0xff491363)],begin:Alignment.topLeft,end:Alignment.bottomRight),borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Text(p.realistic?'Nubank':'Violeta',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w600)),const Spacer(),LineIcon(locked?Glyph.shield:Glyph.card)]),const Spacer(),const Text('••••  ••••  ••••  1234',style:TextStyle(fontSize:22,letterSpacing:2)),const SizedBox(height:16),Text(p.name.toUpperCase(),style:const TextStyle(letterSpacing:1.6,fontSize:12))])),
      const SizedBox(height:20),row('Fatura atual',p.hidden?'••••••':'R\$ 304,87'),row('Limite disponível',p.hidden?'••••••':'R\$ 4.695,13'),row('Vencimento','15 de setembro'),const Divider(color:tile),
      SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Bloqueio temporário'),subtitle:Text(locked?'Cartão demonstrativo bloqueado':'Cartão demonstrativo desbloqueado'),value:locked,onChanged:(v)=>setState(()=>locked=v)),
      action('Ver cartão virtual',()=>result('Cartão de demonstração •••• 5678. Nenhum cartão real é criado ou exposto.')),
    ];
    if(t.contains('Caixinha'))return[
      title(t=='Caixinha Turbo'?'Uma força extra\npara seus planos.':'Pequenos passos.\nGrandes conquistas.'),
      note(t=='Caixinha Turbo'?'Explore a composição visual da Caixinha Turbo. O selo de 115% CDI reproduz a referência e não representa uma oferta.':'Escolha um objetivo e experimente organizar o dinheiro na interface.'),
      Container(padding:const EdgeInsets.all(24),decoration:BoxDecoration(color:const Color(0xff24205d),borderRadius:BorderRadius.circular(24)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const GiftArt(),const SizedBox(height:24),Text(selectedGoal,style:const TextStyle(fontSize:22)),const SizedBox(height:8),Text(p.hidden?'R\$ ••••••':money(goal),style:const TextStyle(fontSize:30)),const SizedBox(height:20),LinearProgressIndicator(value:(goal/1000000).clamp(0.0,1.0),borderRadius:BorderRadius.circular(10),minHeight:6,backgroundColor:Colors.white12,color:const Color(0xffc78beb)),const SizedBox(height:10),const Text('Objetivo demonstrativo: R\$ 10.000,00',style:TextStyle(fontSize:13))])),
      const SizedBox(height:20),Wrap(spacing:8,children:['Minha viagem','Reserva','Novo projeto'].map((s)=>ChoiceChip(label:Text(s),selected:selectedGoal==s,onSelected:(_)=>setState(()=>selectedGoal=s))).toList()),
      action('Experimentar guardar R\$ 100',()=>setState(()=>goal+=10000)),TextButton(onPressed:()=>setState(()=>goal=0),child:const Text('Reiniciar simulação')),
    ];
    if(t=='Ajuda')return[
      title('Como podemos\najudar?'),note('Um guia rápido para explorar o estudo.'),
      for(final item in const [
        ['Como editar nome, foto e saldo?','Toque na foto ou no nome na tela inicial. Altere os campos e toque em Salvar alterações. Você também pode manter pressionado o saldo.'],
        ['Os dados ficam salvos?','Nome, foto e saldo ficam armazenados somente neste aparelho e permanecem ao reabrir o aplicativo. Desinstalar ou limpar os dados remove suas alterações.'],
        ['Posso realizar pagamentos?','Não. Os atalhos demonstram interações de design. Não há conexão com bancos nem movimentações financeiras.'],
        ['Sobre este projeto','Estudo de design independente e sem fins lucrativos. Sem vínculo com a instituição da referência.'],
      ]) ExpansionTile(tilePadding:EdgeInsets.zero,title:Text(item[0]),children:[Padding(padding:const EdgeInsets.only(bottom:16),child:Text(item[1],style:const TextStyle(color:Color(0xffb6b6b6),height:1.5)))]),
    ];
    if(t=='Segurança')return[
      title('Você no controle.'),note('As preferências deste estudo ficam no aparelho.'),
      const LineIcon(Glyph.shield,size:72,color:Color(0xffc78beb)),const SizedBox(height:32),
      SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Ocultar valores'),subtitle:const Text('Esconde saldo e fatura na interface'),value:p.hidden,onChanged:(_)async{try{await p.toggleHidden();}catch(_){if(mounted)showMessage(context,'Não foi possível salvar.');}}),
      const SizedBox(height:24),note('Este aplicativo não pede senhas bancárias, não conecta contas e não transmite seus dados para um servidor.'),
    ];
    if(t=='Área Pix e Transferir')return[
      title('Área Pix'),note('Escolha uma interação para explorar.'),
      for(final item in ['Transferir','Receber','Minhas chaves'])Padding(padding:const EdgeInsets.only(bottom:12),child:Material(color:tile,borderRadius:BorderRadius.circular(16),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:20,vertical:12),leading:const LineIcon(Glyph.pix),title:Text(item),trailing:const LineIcon(Glyph.chevron),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DetailPage(title:item,profile:p)))))),
    ];
    if(t=='Minhas chaves'||t=='Receber')return[
      title(t),note('Nenhuma chave cadastrada. Este estudo não utiliza chaves Pix reais.'),const SizedBox(height:24),
      Container(padding:const EdgeInsets.all(24),decoration:BoxDecoration(color:tile,borderRadius:BorderRadius.circular(20)),child:const Column(children:[LineIcon(Glyph.pix,size:56),SizedBox(height:24),Text('CHAVE DE DEMONSTRAÇÃO',style:TextStyle(letterSpacing:1,fontSize:12)),SizedBox(height:12),SelectableText('estudo-design-sem-valor',style:TextStyle(fontSize:18))])),
      action('Copiar texto de demonstração',()async{await Clipboard.setData(const ClipboardData(text:'estudo-design-sem-valor'));if(mounted)showMessage(context,'Texto de demonstração copiado.');}),
    ];
    if(t=='Pegar emprestado')return[
      title('Explore suas\npossibilidades.'),note('Simulador visual de empréstimo. Não é uma oferta de crédito.'),
      const LineIcon(Glyph.loan,size:64,color:Color(0xffc78beb)),const SizedBox(height:30),
      Form(key:form,child:TextFormField(controller:input,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Quanto gostaria de simular?',prefixText:'R\$ '),validator:validateAmount)),
      action('Simular',(){if(form.currentState!.validate())result('Você explorou uma simulação de ${money(parseMoney(input.text)!)}. Nenhuma contratação foi realizada e nenhuma taxa foi calculada.');}),
    ];
    final recharge=t=='Recarga de celular';
    final pay=t=='Pagar';
    return[
      title(t),note(recharge?'Experimente a seleção de um valor de recarga.':pay?'Explore o fluxo visual de pagamento.':'Experimente a interação com um valor demonstrativo.'),
      if(pay)...[const LineIcon(Glyph.barcode,size:64),const SizedBox(height:24),note('Boleto de demonstração. Não é necessário informar um código real.')],
      if(recharge)...[Wrap(spacing:8,children:[15,20,30,50].map((v)=>ActionChip(label:Text('R\$ $v'),onPressed:()=>setState(()=>input.text='$v,00'))).toList()),const SizedBox(height:24)],
      Form(key:form,child:TextFormField(controller:input,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Valor demonstrativo',prefixText:'R\$ '),validator:validateAmount)),
      action('Continuar',(){if(form.currentState!.validate())result('Interação de ${money(parseMoney(input.text)!)} concluída. Nenhum valor foi transferido, pago ou debitado.');}),
    ];
  }
  String? validateAmount(String? value){final cents=parseMoney(value??'');return cents==null||cents<=0?'Informe um valor maior que zero.':null;}
}
