import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:violeta/scenes.dart';
import 'package:violeta/scene_screens.dart';

void main(){
  TestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('renderiza novas referências e exporta prévias',(tester)async{
    tester.view.physicalSize=const Size(432,864);tester.view.devicePixelRatio=1;
    addTearDown(tester.view.resetPhysicalSize);addTearDown(tester.view.resetDevicePixelRatio);
    SharedPreferences.setMockInitialValues({});
    final prefs=await SharedPreferences.getInstance();
    await tester.runAsync(()async{
      final root=Platform.environment['FLUTTER_ROOT'];
      if(root!=null){
        final font=File('$root/bin/cache/artifacts/material_fonts/Roboto-Regular.ttf');
        if(await font.exists()){
          final loader=FontLoader('Roboto')..addFont(Future.value(ByteData.sublistView(await font.readAsBytes())));
          await loader.load();
        }
      }
      await Directory('previews').create(recursive:true);
    });
    for(final spec in sceneSpecs.where((s)=>s.defaults.isNotEmpty)){
      await tester.runAsync(()=>referenceFor(spec.asset));
      final key=GlobalKey();
      await tester.pumpWidget(MaterialApp(home:RepaintBoundary(key:key,child:ReferenceScreen(record:SceneRecord(spec,prefs)))));
      await tester.pumpAndSettle();
      expect(tester.takeException(),isNull,reason:'Layout ${spec.id}');
      await tester.runAsync(()async{
        final boundary=key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
        final image=await boundary.toImage(pixelRatio:1.5);
        final bytes=await image.toByteData(format:ui.ImageByteFormat.png);
        await File('previews/${spec.id}.png').writeAsBytes(bytes!.buffer.asUint8List());
        image.dispose();
      });
    }
  });
}
