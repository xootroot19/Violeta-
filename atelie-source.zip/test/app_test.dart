import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:violeta/main.dart';
import 'package:violeta/model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  Future<Profile> boot(WidgetTester tester, {bool splash = false, double width = 411}) async {
    tester.view.physicalSize = Size(width, 891);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    SharedPreferences.setMockInitialValues({});
    final p = Profile(await SharedPreferences.getInstance());
    await tester.pumpWidget(StudyApp(profile: p, showSplash: splash));
    await tester.pumpAndSettle();
    return p;
  }
  testWidgets('splash explica o estudo e permite entrar', (tester) async {
    await boot(tester, splash: true);
    expect(find.textContaining('sem fins lucrativos'), findsOneWidget);
    await tester.ensureVisible(find.text('Explorar o estudo'));
    await tester.tap(find.text('Explorar o estudo'));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('enter-nubank')), findsOneWidget);
    await tester.ensureVisible(find.byKey(const Key('enter-nubank')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('enter-nubank')));
    await tester.pumpAndSettle();
    expect(find.text('Olá, Gustavo'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('edita nome e saldo e alterna privacidade', (tester) async {
    final p = await boot(tester);
    await tester.tap(find.text('Olá, Gustavo'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('name-field')), 'Marina');
    await tester.enterText(find.byKey(const Key('balance-field')), '1.234,56');
    await tester.ensureVisible(find.byKey(const Key('save-profile')));
    await tester.tap(find.byKey(const Key('save-profile')));
    await tester.pumpAndSettle();
    expect(find.text('Olá, Marina'), findsOneWidget);
    expect(find.text('R\$ 1.234,56'), findsOneWidget);
    expect(p.balance, 123456);
    await tester.tap(find.byTooltip('Ocultar valores'));
    await tester.pumpAndSettle();
    expect(find.text('R\$ 1.234,56'), findsNothing);
    await tester.tap(find.byTooltip('Mostrar valores'));
    await tester.pumpAndSettle();
    expect(find.text('R\$ 1.234,56'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('dados inválidos não alteram o perfil', (tester) async {
    final p = await boot(tester);
    await tester.tap(find.text('Olá, Gustavo'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('name-field')), '');
    await tester.enterText(find.byKey(const Key('balance-field')), '-50');
    await tester.ensureVisible(find.byKey(const Key('save-profile')));
    await tester.tap(find.byKey(const Key('save-profile')));
    await tester.pumpAndSettle();
    expect(p.name, 'Gustavo');
    expect(p.balance, 58844449);
    expect(find.text('Digite seu nome.'), findsOneWidget);
  });
  testWidgets('layout estreito e navegação dos cartões', (tester) async {
    await boot(tester, width: 360);
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('Meus cartões'));
    await tester.pumpAndSettle();
    await tester.tap(find.byType(SwitchListTile));
    await tester.pumpAndSettle();
    expect(find.text('Cartão demonstrativo bloqueado'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('atalhos acomodam quebras de linha e texto ampliado sem overflow', (tester) async {
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    for (final width in [320.0, 360.0, 411.0]) {
      tester.view.physicalSize = Size(width, 891);
      for (final scale in [1.0, 1.5, 2.0]) {
        await tester.pumpWidget(MaterialApp(
          home: MediaQuery(
            data: MediaQueryData(size: Size(width, 891), textScaler: TextScaler.linear(scale)),
            child: Scaffold(body: SingleChildScrollView(
              child: ShortcutRail(onSelected: (_) {}),
            )),
          ),
        ));
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull,
          reason: 'largura $width, escala $scale, primeiro grupo de atalhos');
        await tester.drag(find.byType(ListView), const Offset(-500, 0));
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull,
          reason: 'largura $width, escala $scale, últimos atalhos');
      }
    }
  });

}
