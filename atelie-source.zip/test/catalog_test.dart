import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:violeta/scenes.dart';
import 'package:violeta/catalog.dart';
import 'package:violeta/scene_screens.dart';

void main(){
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(()=>SharedPreferences.setMockInitialValues({}));
  test('catálogo possui 7 famílias e 11 variantes com estados isolados',()async{
    expect(sceneSpecs.map((s)=>s.family).toSet().length,7);
    expect(sceneSpecs.length,11);
    final prefs=await SharedPreferences.getInstance();
    final first=SceneRecord(sceneSpecs.firstWhere((s)=>s.id=='next-iniciais'),prefs);
    final second=SceneRecord(sceneSpecs.firstWhere((s)=>s.id=='next-foto'),prefs);
    await first.save({...first.values,'name':'Ana','balance':10000},null);
    await second.save({...second.values,'name':'Bia','balance':20000},null);
    expect(SceneRecord(first.spec,prefs).text('name'),'Ana');
    expect(SceneRecord(second.spec,prefs).text('name'),'Bia');
    expect(SceneRecord(first.spec,prefs).cents('balance'),10000);
    expect(SceneRecord(second.spec,prefs).cents('balance'),20000);
  });
  testWidgets('modo estudo mostra controles e modo realista os remove',(tester)async{
    tester.view.physicalSize=const Size(432,864);tester.view.devicePixelRatio=1;
    addTearDown(tester.view.resetPhysicalSize);addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(home:StudioSession(spec:sceneSpecs[4],initialRealistic:false,
      screen:()=>const Scaffold(body:Center(child:Text('Tela da instituição'))),onEdit:(_){})));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('study-toolbar')),findsOneWidget);
    expect(find.byKey(const Key('compare-study')),findsOneWidget);
    await tester.tap(find.byKey(const Key('clean-mode')));await tester.pumpAndSettle();
    expect(find.byKey(const Key('study-toolbar')),findsNothing);
    expect(find.text('Tela da instituição'),findsOneWidget);
    await tester.longPress(find.text('Tela da instituição'));await tester.pumpAndSettle();
    await tester.tap(find.text('Abrir bancada de estudo'));await tester.pumpAndSettle();
    expect(find.byKey(const Key('study-toolbar')),findsOneWidget);
  });
  testWidgets('transferência exige valor válido e não altera saldo',(tester)async{
    final prefs=await SharedPreferences.getInstance();
    final record=SceneRecord(sceneSpecs.firstWhere((s)=>s.id=='next-transferencia'),prefs);
    await tester.pumpWidget(MaterialApp(home:NextTransfer(record:record)));await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('transfer-amount')),'999.999,99');
    await tester.ensureVisible(find.byKey(const Key('transfer-next')));await tester.tap(find.byKey(const Key('transfer-next')));await tester.pumpAndSettle();
    expect(find.text('O valor supera o saldo demonstrativo.'),findsOneWidget);
    await tester.enterText(find.byKey(const Key('transfer-amount')),'800,00');
    await tester.ensureVisible(find.byKey(const Key('transfer-next')));await tester.tap(find.byKey(const Key('transfer-next')));await tester.pumpAndSettle();
    expect(find.text('Revisar demonstração'),findsOneWidget);
    await tester.tap(find.text('Concluir estudo'));await tester.pumpAndSettle();
    expect(record.cents('balance'),4397718);
  });
}
