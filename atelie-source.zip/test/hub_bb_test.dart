import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:violeta/main.dart';
import 'package:violeta/hub.dart';
import 'package:violeta/bb.dart';
import 'package:violeta/model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));
  void screen(WidgetTester tester, {double width = 411}) {
    tester.view.physicalSize = Size(width, 891);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
  }
  test('BB e Nubank persistem dados separados', () async {
    final prefs = await SharedPreferences.getInstance();
    final nu = Profile(prefs);
    final bb = BBProfile(prefs);
    await nu.update('Ana', 98765, null);
    await bb.save('Bia', 50000000000, 150000, '20/Out', hide: true);
    final reopened = BBProfile(prefs);
    expect(reopened.name, 'Bia');
    expect(reopened.balance, 50000000000);
    expect(reopened.scheduled, 150000);
    expect(reopened.until, '20/Out');
    expect(reopened.hidden, isTrue);
    final other = Profile(prefs)..restoreSnapshot();
    expect(other.name, 'Ana');
    expect(other.balance, 98765);
  });
  testWidgets('aviso obrigatório precede hub e abertura realista', (tester) async {
    screen(tester);
    final p = Profile(await SharedPreferences.getInstance());
    await tester.pumpWidget(StudyApp(profile: p));
    await tester.pumpAndSettle();
    expect(find.byType(StudyNotice), findsOneWidget);
    expect(find.byType(StudyHub), findsNothing);
    await tester.ensureVisible(find.text('Explorar o estudo'));
    await tester.tap(find.text('Explorar o estudo'));
    await tester.pumpAndSettle();
    // The test font can move the mode selector outside the visible viewport.
    // Scroll to the actual control before tapping, just as a person would.
    final realisticOption = find.text('Realista');
    await tester.ensureVisible(realisticOption);
    await tester.pumpAndSettle();
    await tester.tap(realisticOption);
    await tester.pumpAndSettle();
    final mode = tester.widget<SegmentedButton<bool>>(
      find.byKey(const Key('study-mode')),
    );
    expect(mode.selected, contains(true),
      reason: 'O modo Realista deve estar selecionado antes de abrir o BB.');
    await tester.ensureVisible(find.byKey(const Key('enter-bb')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('enter-bb')));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));
    expect(find.byType(BrandOpening), findsOneWidget,
      reason: 'A abertura de marca deve aparecer após selecionar Realista.');
    await tester.pump(const Duration(seconds: 2));
    await tester.pumpAndSettle();
    expect(find.text('Olá, Vitoria'), findsOneWidget);
    expect(find.text('Loja BB'), findsOneWidget);
    await tester.tap(find.byTooltip('Sair para o hub'));
    await tester.pumpAndSettle();
    expect(find.byType(StudyHub), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('BB edita nome e valores sem oferecer foto', (tester) async {
    screen(tester);
    final p = BBProfile(await SharedPreferences.getInstance());
    await tester.pumpWidget(MaterialApp(home: BBHome(profile: p, realistic: true)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Perfil'));
    await tester.pumpAndSettle();
    expect(find.byType(Avatar), findsNothing);
    await tester.enterText(find.byKey(const Key('bb-name')), 'Marina');
    await tester.enterText(find.byKey(const Key('bb-balance')), '1.234,56');
    await tester.enterText(find.byKey(const Key('bb-scheduled')), '200,00');
    await tester.ensureVisible(find.byKey(const Key('bb-save')));
    await tester.tap(find.byKey(const Key('bb-save')));
    await tester.pumpAndSettle();
    expect(find.text('Olá, Marina'), findsOneWidget);
    expect(find.text('R\$ 1.234,56'), findsOneWidget);
    expect(p.scheduled, 20000);
    await tester.tap(find.byTooltip('Ocultar valores BB'));
    await tester.pumpAndSettle();
    expect(find.text('R\$ 1.234,56'), findsNothing);
    expect(tester.takeException(), isNull);
  });
  testWidgets('BB acomoda telas estreitas sem overflow', (tester) async {
    screen(tester, width: 320);
    final p = BBProfile(await SharedPreferences.getInstance());
    await tester.pumpWidget(MaterialApp(home: BBHome(profile: p, realistic: true)));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('Menu'));
    await tester.pumpAndSettle();
    expect(find.text('Hub de estudos'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
