import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:violeta/model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));
  test('formata centavos e valida valores no padrão brasileiro', () {
    expect(money(58844449), 'R\$ 588.444,49');
    expect(money(0), 'R\$ 0,00');
    expect(money(30487), 'R\$ 304,87');
    expect(parseMoney('588.444,49'), 58844449);
    expect(parseMoney('0,05'), 5);
    expect(parseMoney('12,5'), 1250);
    expect(parseMoney('1.234'), 123400);
    for (final invalid in ['', '-1', 'abc', '1.2.3', '12,345', '1000000000']) {
      expect(parseMoney(invalid), isNull, reason: invalid);
    }
  });
  test('nome, saldo, foto e privacidade sobrevivem a uma nova instância', () async {
    final prefs = await SharedPreferences.getInstance();
    final original = Profile(prefs);
    final photo = Uint8List.fromList([1, 2, 3, 4]);
    await original.update('Marina', 123456, photo);
    await original.toggleHidden();
    final reopened = Profile(prefs)..restoreSnapshot();
    expect(reopened.name, 'Marina');
    expect(reopened.balance, 123456);
    expect(reopened.photo, photo);
    expect(reopened.hidden, isTrue);
    await reopened.update('Marina', 0, null);
    final reset = Profile(prefs)..restoreSnapshot();
    expect(reset.photo, isNull);
    expect(reset.balance, 0);
  });
}
